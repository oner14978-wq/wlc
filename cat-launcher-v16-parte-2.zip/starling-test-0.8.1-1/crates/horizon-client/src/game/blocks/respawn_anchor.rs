//! `RespawnAnchorBlock` in the game: glowstone charges it (`useItemOn`), a
//! right click on a charged anchor sets the respawn point in the Nether and
//! blows it up anywhere else (`useWithoutItem`), and respawning goes to it
//! (`ServerPlayer.findRespawnAndUseSpawnBlock`, `PlayerList.respawn`),
//! using a charge.
use super::{Dim, Game};
use horizon_client::{
    Result,
    blocks::Fluid,
    collisions::{SceneCollisions, no_collision_empty},
    items::ItemStack,
    mobs::Who,
    stand_up::{StandUpLevel, StandUpType, bed_forward, stand_up_fallback},
    text::Text,
};
use horizon_core::{
    geometry::{Aabb, Axis, Vec3, VoxelShape},
    position::BlockPos,
};
use horizon_world::{
    collision_context::CollisionContext, level::data::state_flags, registry::BlockStateId,
};
use mod_api::client::first_person::Hand;

/// `ServerPlayer.RespawnConfig`: a respawn point other than the world spawn
/// that the game resolves through its block (a respawn anchor).
#[derive(Clone, Copy, Debug, PartialEq)]
pub(super) struct RespawnConfig {
    pub dim: Dim,
    pub pos: [i32; 3],
    pub yaw: f32,
    pub pitch: f32,
    pub forced: bool,
}

/// A respawn point as a player's save keeps it (`respawn`): dimension,
/// block, yaw, pitch and whether it is forced.
pub(super) type SavedRespawn = (String, [i32; 3], f32, f32, bool);

impl RespawnConfig {
    /// `RespawnData.of`: the yaw wrapped to [-180, 180).
    pub(super) fn wrapped(dim: Dim, pos: [i32; 3], yaw: f32, forced: bool) -> Self {
        Self {
            dim,
            pos,
            yaw: wrap_degrees(f64::from(yaw)) as f32,
            pitch: 0.0,
            forced,
        }
    }
    /// `SetSpawnCommand`: the forced literal, with its already parsed angles.
    pub(super) fn forced(dim: Dim, pos: [i32; 3], yaw: f32, pitch: f32) -> Self {
        Self {
            dim,
            pos,
            yaw,
            pitch,
            forced: true,
        }
    }
    pub(super) fn from_saved((dim, pos, yaw, pitch, forced): &SavedRespawn) -> Self {
        Self {
            dim: Dim::from_id(dim),
            pos: *pos,
            yaw: *yaw,
            pitch: *pitch,
            forced: *forced,
        }
    }
    pub(super) fn saved(&self) -> SavedRespawn {
        (
            self.dim.id().to_owned(),
            self.pos,
            self.yaw,
            self.pitch,
            self.forced,
        )
    }
}

/// `RespawnAnchorBlock.RESPAWN_HORIZONTAL_OFFSETS`, then the same a block
/// below, a block above, and straight above.
const HORIZONTAL: [[i32; 3]; 8] = [
    [0, 0, -1],
    [-1, 0, 0],
    [0, 0, 1],
    [1, 0, 0],
    [-1, 0, -1],
    [1, 0, -1],
    [-1, 0, 1],
    [1, 0, 1],
];
fn respawn_offsets() -> impl Iterator<Item = [i32; 3]> {
    HORIZONTAL
        .into_iter()
        .chain(HORIZONTAL.into_iter().map(|[x, y, z]| [x, y - 1, z]))
        .chain(HORIZONTAL.into_iter().map(|[x, y, z]| [x, y + 1, z]))
        .chain(std::iter::once([0, 1, 0]))
}

/// What a right click with an item does to an anchor before `useWithoutItem`.
pub(super) enum AnchorUse {
    /// Glowstone charged it.
    Charged,
    /// `PASS`: the off hand's glowstone charges it instead.
    Pass,
    /// `TRY_WITH_EMPTY_HAND`, or not an anchor.
    Other,
}

impl Game<'_> {
    pub(super) fn is_anchor(&self, state: BlockStateId) -> bool {
        &*self.res.facts().get(state).name == "minecraft:respawn_anchor"
    }
    fn anchor_charges(&self, state: BlockStateId) -> i32 {
        self.pack
            .assets
            .registry
            .state(state)
            .and_then(|s| s.properties.get("charges"))
            .and_then(|c| c.parse().ok())
            .unwrap_or(0)
    }
    fn anchor_with_charges(&self, state: BlockStateId, charges: i32) -> Option<BlockStateId> {
        let mut s = self.pack.assets.registry.state(state)?.clone();
        s.properties.insert("charges".into(), charges.to_string());
        self.pack.assets.registry.resolve(&s).ok()
    }
    /// `RespawnAnchorBlock.canSetSpawn`: the `respawn_anchor_works` attribute
    /// (only the Nether's dimension type sets it).
    pub(super) fn anchor_works(&self) -> bool {
        self.dimension_type().respawn_anchor_works
    }
    /// `RespawnAnchorBlock.charge`: one more charge, the block change and the sound.
    fn charge_anchor(
        &mut self,
        pos: [i32; 3],
        state: BlockStateId,
        who: Option<Who>,
    ) -> Result<()> {
        let Some(next) = self.anchor_with_charges(state, self.anchor_charges(state) + 1) else {
            return Ok(());
        };
        self.level_set(pos, next)?;
        self.post_block_game_event("minecraft:block_change", pos, who, Some(next));
        let at = [
            f64::from(pos[0]) + 0.5,
            f64::from(pos[1]) + 0.5,
            f64::from(pos[2]) + 0.5,
        ];
        self.audio
            .play("minecraft:block.respawn_anchor.charge", Some(at), 1.0, 1.0);
        Ok(())
    }
    /// `RespawnAnchorBlock.useItemOn`'s test: `held` is glowstone
    /// (`isRespawnFuel`) and the block at `pos` is an anchor that takes another
    /// charge (`canBeCharged`).
    pub(super) fn anchor_takes(&self, pos: [i32; 3], held: Option<&ItemStack>) -> bool {
        let state = self.world.block(pos[0], pos[1], pos[2]);
        held.is_some_and(|s| &*s.item == "minecraft:glowstone")
            && self.is_anchor(state)
            && self.anchor_charges(state) < 4
    }
    /// `RespawnAnchorBlock.useItemOn` with `held` in the hand that acts.
    pub(super) fn use_respawn_anchor(
        &mut self,
        pos: [i32; 3],
        held: Option<&ItemStack>,
    ) -> Result<AnchorUse> {
        let state = self.world.block(pos[0], pos[1], pos[2]);
        if !self.is_anchor(state) {
            return Ok(AnchorUse::Other);
        }
        let fuel = |s: Option<&ItemStack>| s.is_some_and(|s| &*s.item == "minecraft:glowstone");
        let chargeable = self.anchor_charges(state) < 4;
        if fuel(held) && chargeable {
            let used = held.cloned();
            self.charge_anchor(pos, state, Some(Who::Player))?;
            // itemStack.consume(1, player); the criterion sees the stack as used.
            self.consume_held();
            if let Some(stack) = used {
                self.trigger_block("minecraft:item_used_on_block", pos, &stack);
            }
            return Ok(AnchorUse::Charged);
        }
        if self.hand == Hand::Main && fuel(self.offhand.as_ref()) && chargeable {
            return Ok(AnchorUse::Pass);
        }
        Ok(AnchorUse::Other)
    }
    /// The mods' say on a server player's respawn point about to be set to
    /// `pos` in `dim` (`ServerPlayer.setRespawnPosition`, NeoForge's
    /// `PlayerSetSpawnEvent`): true when one canceled.
    pub(super) fn spawn_point_change(
        &mut self,
        dim: Dim,
        pos: Option<[i32; 3]>,
        forced: bool,
    ) -> bool {
        let (Some(player), Some(name)) = (self.lan_acting_uuid, self.lan_acting_name.clone())
        else {
            return false;
        };
        let mut cancel = false;
        let id = self.own_entity_id();
        self.native_player_set_spawn(mod_api::__private::PlayerSetSpawnCall {
            player,
            player_entity_id: id,
            name: &name,
            dimension: dim.id(),
            pos,
            forced,
            cancel: &mut cancel,
        });
        cancel
    }
    /// `ServerPlayer.setRespawnPosition` for the player in place, as
    /// `/spawnpoint` sets it: the point becomes `config`, or none for None,
    /// unless a mod cancels the change (the answer is false then). A point
    /// replaces the fallback spawn, which the world spawn then stands for.
    pub(super) fn set_respawn_point(&mut self, config: Option<RespawnConfig>) -> bool {
        let (dim, pos, forced) =
            config.map_or((self.dim, None, false), |c| (c.dim, Some(c.pos), c.forced));
        if self.spawn_point_change(dim, pos, forced) {
            return false;
        }
        if config.is_some() {
            self.spawn = None;
        }
        self.respawn_config = config;
        true
    }
    /// `RespawnAnchorBlock.useWithoutItem` on a charged anchor: outside the
    /// Nether it explodes; inside, it becomes the respawn point.
    pub(super) fn respawn_anchor_used(&mut self, pos: [i32; 3]) -> Result<()> {
        let state = self.world.block(pos[0], pos[1], pos[2]);
        if !self.anchor_works() {
            return self.explode_anchor(pos, state);
        }
        let config = RespawnConfig {
            dim: self.dim,
            pos,
            yaw: 0.0,
            pitch: 0.0,
            forced: false,
        };
        // RespawnConfig.isSamePosition: dimension and block.
        let same = self
            .respawn_config
            .is_some_and(|c| c.dim == config.dim && c.pos == config.pos);
        if !same {
            if self.spawn_point_change(self.dim, Some(pos), false) {
                return Ok(());
            }
            // setRespawnPosition(config, true): the message, the point; the
            // anchor replaces a bed.
            self.system_message(Text::translate("block.minecraft.set_spawn", &[]));
            self.respawn_config = Some(config);
            if let Some([x, y, z]) = self.level.world_spawn {
                self.spawn = Some(Vec3::new(
                    f64::from(x) + 0.5,
                    f64::from(y),
                    f64::from(z) + 0.5,
                ));
            }
            let at = [
                f64::from(pos[0]) + 0.5,
                f64::from(pos[1]) + 0.5,
                f64::from(pos[2]) + 0.5,
            ];
            self.audio.play(
                "minecraft:block.respawn_anchor.set_spawn",
                Some(at),
                1.0,
                1.0,
            );
        }
        Ok(())
    }
    /// `RespawnAnchorBlock.isWaterThatWouldFlow`.
    fn water_would_flow(&self, p: [i32; 3]) -> bool {
        let f = self.res.facts().get(self.world.block(p[0], p[1], p[2]));
        if f.fluid != Fluid::Water {
            return false;
        }
        if f.fluid_level == 8 && !f.fluid_falling {
            return true;
        }
        if f.fluid_level < 2 {
            return false;
        }
        self.res
            .facts()
            .get(self.world.block(p[0], p[1] - 1, p[2]))
            .fluid
            != Fluid::Water
    }
    /// `RespawnAnchorBlock.explode`: the anchor goes, then a power 5 fiery
    /// explosion (`badRespawnPointExplosion`, `ExplosionInteraction.BLOCK`)
    /// whose centre resists like water when water would flow into it.
    fn explode_anchor(&mut self, pos: [i32; 3], _state: BlockStateId) -> Result<()> {
        self.level_set(pos, self.world.air)?;
        let horizontal = [[0, 0, -1], [0, 0, 1], [-1, 0, 0], [1, 0, 0]]
            .into_iter()
            .any(|d| self.water_would_flow([pos[0] + d[0], pos[1], pos[2] + d[2]]));
        let above = self
            .res
            .facts()
            .get(self.world.block(pos[0], pos[1] + 1, pos[2]))
            .fluid
            == Fluid::Water;
        let in_water = horizontal || above;
        let center = [
            f64::from(pos[0]) + 0.5,
            f64::from(pos[1]) + 0.5,
            f64::from(pos[2]) + 0.5,
        ];
        self.block_explosion(center, in_water.then_some(pos))
    }
    /// `StrawBedBlock.destroyBed`: the break sound, then the bed is air.
    pub(super) fn destroy_straw_bed(&mut self, head: [i32; 3]) -> Result<()> {
        let center = [
            f64::from(head[0]) + 0.5,
            f64::from(head[1]) + 0.5,
            f64::from(head[2]) + 0.5,
        ];
        self.audio.play(
            "minecraft:block.straw_bed.break_leave",
            Some(center),
            1.0,
            1.0,
        );
        self.level_set(head, self.world.air)
    }
    /// `BedRule.destroyOnUse` of the dimension's `bed_rule` and
    /// `straw_bed_rule`: true in the Nether and the End.
    pub(super) fn beds_destroy_on_use(&self) -> bool {
        self.dimension_type().bed_rule.destroy_on_use
    }
    /// `AbstractBedBlock.useWithoutItem` where the bed rule destroys on use
    /// (the bed's head at `head`): `BedBlock.destroyOnUse` removes both
    /// halves and explodes; `StrawBedBlock` just falls apart.
    pub(super) fn destroy_bed_on_use(&mut self, head: [i32; 3]) -> Result<()> {
        let state = self.world.block(head[0], head[1], head[2]);
        let name = self.res.facts().get(state).name.clone();
        let center = [
            f64::from(head[0]) + 0.5,
            f64::from(head[1]) + 0.5,
            f64::from(head[2]) + 0.5,
        ];
        if &*name == "minecraft:straw_bed" {
            return self.destroy_straw_bed(head);
        }
        // removeBlock(head), then the foot behind it if it is still this bed.
        let facing = self
            .pack
            .assets
            .registry
            .state(state)
            .and_then(|s| s.properties.get("facing").cloned())
            .unwrap_or_default();
        let back = match facing.as_str() {
            "north" => [0, 0, 1],
            "south" => [0, 0, -1],
            "west" => [1, 0, 0],
            _ => [-1, 0, 0],
        };
        self.level_set(head, self.world.air)?;
        let foot = [head[0] + back[0], head[1], head[2] + back[2]];
        if self
            .res
            .facts()
            .get(self.world.block(foot[0], foot[1], foot[2]))
            .name
            == name
        {
            self.level_set(foot, self.world.air)?;
        }
        self.block_explosion(center, None)
    }
    /// `Level.explode(null, badRespawnPointExplosion(center), calculator,
    /// center, 5, true, ExplosionInteraction.BLOCK)` (beds and anchors):
    /// `water_at` is the block that resists like water.
    pub(super) fn block_explosion(
        &mut self,
        center: [f64; 3],
        water_at: Option<[i32; 3]>,
    ) -> Result<()> {
        let interaction =
            self.destroy_type(horizon_client::gamerules::vanilla::BLOCK_EXPLOSION_DROP_DECAY);
        self.server_explode_as(
            center,
            5.0,
            interaction,
            true,
            "minecraft:bad_respawn_point",
            water_at.map(|p| (p, 100.0)),
        )
    }

    // ---- respawning -------------------------------------------------------

    /// This level as the stand-up search reads it (`crate::stand_up`).
    fn stand_up_level(&self) -> StandUpLevel<'_, '_> {
        StandUpLevel {
            world: &self.world,
            registry: self.pack.assets.registry,
            facts: self.res.facts(),
            collision: self.collision,
            block_tags: &self.res.items().block_tags,
            border: Some(self.border.geometry()),
        }
    }
    /// `BlockState.getCollisionShape(level, pos)`: the shape under the empty
    /// collision context.
    pub(super) fn block_collision_shape(&self, p: [i32; 3]) -> VoxelShape {
        self.block_collision_shape_in(&self.world, p)
    }
    pub(super) fn block_collision_shape_in(
        &self,
        world: &horizon_client::world::World,
        p: [i32; 3],
    ) -> VoxelShape {
        let state = world.block(p[0], p[1], p[2]);
        let binding = self.collision;
        let mut scene = SceneCollisions {
            world,
            binding,
            subject: None,
        };
        binding
            .collision_shape_with_context(
                &mut scene,
                state,
                BlockPos::new(p[0], p[1], p[2]),
                &CollisionContext::empty(false),
            )
            .unwrap_or_else(|_| VoxelShape::empty())
    }
    /// `DismountHelper.canDismountTo(level, entity, box)`: no block collides
    /// with the box and it is inside the world border.
    pub(super) fn can_dismount_to(&self, bounds: Aabb) -> bool {
        let mut scene = SceneCollisions {
            world: &self.world,
            binding: self.collision,
            subject: None,
        };
        if !no_collision_empty(&mut scene, bounds) {
            return false;
        }
        // WorldBorder.isWithinBounds(box).
        let (lo, hi) = (bounds.min(Axis::X), bounds.max(Axis::X) - 1.0e-5);
        let (lz, hz) = (bounds.min(Axis::Z), bounds.max(Axis::Z) - 1.0e-5);
        self.border.contains(lo, lz) && self.border.contains(hi, hz)
    }
    pub(super) fn named_block_in_tag(&self, tag: &str, block: &str) -> bool {
        self.res
            .items()
            .block_tags
            .get(tag)
            .is_some_and(|s| s.contains(block))
    }
    /// `DismountHelper.findSafeDismountLocation` for a standing player.
    fn safe_dismount_location(&self, p: [i32; 3], check_dangerous: bool) -> Option<Vec3> {
        self.stand_up_level()
            .safe_dismount_location(StandUpType::PLAYER, p, check_dangerous)
    }
    /// `Block.isPossibleToRespawnInThis`: neither solid nor liquid; banners,
    /// signs and pressure plates override it to always.
    fn possible_to_respawn_in(&self, state: BlockStateId) -> bool {
        let f = self.res.facts().get(state);
        let name = &*f.name;
        let liquid = self.res.behaviours().facts(state).flags & state_flags::LIQUID != 0;
        name.ends_with("_banner")
            || f.sign_form().is_some()
            || name.ends_with("_pressure_plate")
            || !(f.legacy_solid || liquid)
    }
    /// `RespawnAnchorBlock.findStandUpPosition`: a safe spot around the
    /// anchor, else any spot.
    pub(super) fn anchor_stand_up(&self, pos: [i32; 3]) -> Option<Vec3> {
        for check in [true, false] {
            for d in respawn_offsets() {
                let p = [pos[0] + d[0], pos[1] + d[1], pos[2] + d[2]];
                if let Some(at) = self.safe_dismount_location(p, check) {
                    return Some(at);
                }
            }
        }
        None
    }
    /// `AbstractBedBlock.findStandUpPosition` for a player beside the bed
    /// whose head is at `pos`, facing `forward`, set from `yaw`.
    pub(super) fn bed_stand_up(&self, pos: [i32; 3], forward: [i32; 3], yaw: f32) -> Option<Vec3> {
        self.stand_up_level()
            .bed_stand_up(StandUpType::PLAYER, pos, forward, yaw)
    }
    pub(super) fn is_bed(&self, state: BlockStateId) -> bool {
        self.res.facts().get(state).name.ends_with("_bed")
    }
    /// `LivingEntity.stopSleeping`: when the block at `head` is still a bed,
    /// stand at `AbstractBedBlock.findStandUpPosition` (else 0.1 above the
    /// block over the head), turned toward the bed's bottom centre with a
    /// level pitch.
    pub(super) fn bed_wake_pose(&self, head: [i32; 3], yaw: f32) -> Option<(Vec3, f32)> {
        let state = self.world.block(head[0], head[1], head[2]);
        if !self.is_bed(state) {
            return None;
        }
        let facing = self.bed_forward(state);
        let stand = self
            .bed_stand_up(head, facing, yaw)
            .unwrap_or_else(|| stand_up_fallback(head));
        Some((stand, look_at_yaw(stand, head)))
    }
    /// The bed's `facing`, as a step.
    pub(super) fn bed_forward(&self, state: BlockStateId) -> [i32; 3] {
        let facing = self.pack.assets.registry.state(state);
        bed_forward(
            facing
                .and_then(|s| s.properties.get("facing"))
                .map(String::as_str),
        )
    }
    /// `BedRule.canSetSpawn` of the bed's rule attribute (`bed_rule`,
    /// `straw_bed_rule`): only the Overworld's beds set the spawn, straw
    /// beds never.
    pub(super) fn bed_sets_spawn(&self, state: BlockStateId) -> bool {
        let straw = &*self.res.facts().get(state).name == "minecraft:straw_bed";
        let facts = self.dimension_type();
        let rule = if straw {
            facts.straw_bed_rule
        } else {
            facts.bed_rule
        };
        rule.can_set_spawn.test(self.dark_outside())
    }
    /// `ServerPlayer.findRespawnAndUseSpawnBlock` for a config in the loaded
    /// dimension: position and angles, using an anchor's charge; a bed's
    /// stand-up spot. A forced point (`spawnpoint`) that is no anchor or bed
    /// holds if a player fits in it; anything else is gone.
    pub(super) fn find_respawn_and_use(
        &mut self,
        c: RespawnConfig,
        consume: bool,
    ) -> Result<Option<(Vec3, f32, f32)>> {
        let state = self.world.block(c.pos[0], c.pos[1], c.pos[2]);
        if !(self.is_anchor(state)
            && (c.forced || self.anchor_charges(state) > 0)
            && self.anchor_works())
        {
            // A bed where its bed rule lets it set the spawn.
            if self.is_bed(state) && self.bed_sets_spawn(state) {
                let facing = self.bed_forward(state);
                let stand = self.bed_stand_up(c.pos, facing, c.yaw);
                return Ok(stand.map(|p| (p, look_at_yaw(p, c.pos), 0.0)));
            }
            let [x, y, z] = c.pos;
            let free = c.forced
                && !self.is_anchor(state)
                && self.possible_to_respawn_in(state)
                && self.possible_to_respawn_in(self.world.block(x, y + 1, z));
            let at = Vec3::new(f64::from(x) + 0.5, f64::from(y) + 0.1, f64::from(z) + 0.5);
            return Ok(free.then_some((at, c.yaw, c.pitch)));
        }
        let stand = self.anchor_stand_up(c.pos);
        if !c.forced
            && consume
            && stand.is_some()
            && let Some(next) = self.anchor_with_charges(state, self.anchor_charges(state) - 1)
        {
            self.level_set(c.pos, next)?;
        }
        Ok(stand.map(|p| (p, look_at_yaw(p, c.pos), 0.0)))
    }
}

/// `RespawnPosAngle.calculateLookAtYaw`: the yaw from the position to the
/// bottom centre of the block.
fn look_at_yaw(position: Vec3, block: [i32; 3]) -> f32 {
    let d = Vec3::new(
        f64::from(block[0]) + 0.5 - position.x,
        f64::from(block[1]) - position.y,
        f64::from(block[2]) + 0.5 - position.z,
    )
    .normalize();
    // Mth.atan2(z, x) * 180.0F / (float) Math.PI - 90.0: the compiled code
    // multiplies by the folded float constant widened to double.
    let degrees = horizon_core::geometry::trig::atan2(d.z, d.x)
        * f64::from(horizon_core::geometry::trig::RAD_TO_DEG)
        - 90.0;
    wrap_degrees(degrees) as f32
}
/// `Mth.wrapDegrees(double)`.
fn wrap_degrees(degrees: f64) -> f64 {
    let mut d = degrees % 360.0;
    if d >= 180.0 {
        d -= 360.0;
    }
    if d < -180.0 {
        d += 360.0;
    }
    d
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn waking_up_next_to_a_bed_looks_toward_the_bed_head() {
        let head = [10, 64, 5];
        // Standing one block south of the bed head (z + 1) looks north (180 deg).
        let south = Vec3::new(10.5, 64.0, 6.5);
        assert!((look_at_yaw(south, head).abs() - 180.0).abs() < 1.0e-4);
        // Standing one block east of the bed head (x + 1) looks west (90 deg).
        let east = Vec3::new(11.5, 64.0, 5.5);
        assert!((look_at_yaw(east, head) - 90.0).abs() < 1.0e-4);
    }
}

#[cfg(test)]
mod connected_spawnpoint_rotation_tests {
    use crate::game::{Game, lan::LanSettings};
    use horizon_client::{
        chunk::Chunk,
        lan::{Joined, NetConfig, Out, PlayerSender, guest::Guest, hub::HubConfig, playerdata},
    };
    use horizon_protocol::packets::{
        configuration::ClientInformation,
        play::{self, Clientbound as C, Serverbound as S},
    };
    use std::sync::{Arc, atomic::AtomicI32, mpsc};

    fn command(game: &mut Game<'_>, text: &str) {
        game.chat_capture = Some(Vec::new());
        game.ui.registries.permission = 4;
        let dispatcher = horizon_client::command::vanilla::build_for(false, true);
        let parsed = dispatcher.parse(text, &game.ui.registries);
        let (ctx, _) = parsed
            .executable()
            .expect("actual registered dedicated command");
        let (root, ctx) = (parsed.context.clone(), ctx.clone());
        assert_eq!(game.run_chain(&root, &ctx).unwrap(), 1, "{text}");
        assert!(
            !game.chat_capture.take().unwrap().is_empty(),
            "actual command feedback {text}"
        );
    }

    #[test]
    #[ignore = "prepared resources and isolated scratch homes/cwd"]
    fn command_forced_free_point_survives_real_guest_death_and_respawn_packet() {
        let mut resources = None;
        let mut game = crate::game::game_tests::tests::server_game(&mut resources);
        game.set_allow_commands(true);
        let scratch = std::env::temp_dir().join(format!(
            "horizon-forced-spawn-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&scratch).unwrap();
        game.world_root = scratch.clone();
        // Fixture setup through the existing column insertion API; admit every lit column below.
        for x in -2..=2 {
            for z in -2..=2 {
                game.streaming
                    .insert_remote(&mut game.world, Chunk::empty(x, z));
                assert!(game.streaming.is_lit(x, z));
            }
        }
        let stone = game
            .pack
            .assets
            .registry
            .default_state("minecraft:stone")
            .unwrap();
        let air = game
            .pack
            .assets
            .registry
            .default_state("minecraft:air")
            .unwrap();
        game.world.set(12, 99, 12, stone).unwrap();
        for y in [100, 101] {
            game.world.set(12, y, 12, air).unwrap();
        }
        assert_eq!(game.world.block(12, 99, 12), stone);
        assert!(game.world.loaded(12, 12));
        game.level.world_spawn = Some([4, 100, 4]);
        game.level.world_spawn_angle = [-30.0, -5.0];
        game.lan_host(
            LanSettings {
                port: 0,
                guest_commands: true,
                force_game_mode: false,
            },
            NetConfig {
                listen: false,
                announce: false,
                ..NetConfig::loopback(0, String::new(), 2)
            },
            HubConfig {
                default_game_mode: 0,
                guest_commands: true,
                force_game_mode: false,
                hardcore: false,
                view_distance: 2,
                simulation_distance: 2,
                dimension: "minecraft:overworld".into(),
                allow_flight: false,
                seed: 0,
                max_players: 2,
                integrated: false,
                levels: Default::default(),
            },
        )
        .unwrap();
        let (tx, rx) = mpsc::channel();
        let mut guest = Guest::new(
            Joined {
                conn: 7,
                uuid: 77,
                name: "Alice".into(),
                properties: Vec::new(),
                info: ClientInformation::new(2),
                brand: "test".into(),
                sender: PlayerSender::new(tx, Arc::default()),
                latency: Arc::new(AtomicI32::new(0)),
                address: "127.0.0.1:7".parse().unwrap(),
                expected: false,
            },
            7,
            [4.5, 100.0, 4.5],
            2,
        );
        guest.dimension = "minecraft:overworld".into();
        guest.placed = true;
        guest.loaded = true;
        guest.health = 20.0;
        guest.game_mode = 0;
        guest.yaw = 0.0;
        guest.pitch = 0.0;
        game.lan.as_mut().unwrap().hub.guests.push(guest);
        let clock = game.world.game_time;
        command(&mut game, "spawnpoint Alice 12 100 12 45 10");
        let host = game.lan.as_ref().unwrap();
        assert!(host.owner.is_none());
        let guest = &host.hub.guests[0];
        assert_eq!(
            (guest.uuid, guest.health, guest.game_mode, guest.position),
            (77, 20.0, 0, [4.5, 100.0, 4.5])
        );
        let tag = playerdata::player_tag(guest);
        let respawn = tag
            .get("respawn")
            .expect("actual serialized personal configuration")
            .clone();
        assert_eq!(
            respawn.get("yaw"),
            Some(&horizon_core::nbt::Tag::Float(45f32.to_bits()))
        );
        assert_eq!(
            respawn.get("pos"),
            Some(&horizon_core::nbt::Tag::IntArray(vec![12, 100, 12]))
        );
        command(&mut game, "kill Alice");
        game.tick_lan(false);
        let host = game.lan.take().unwrap();
        assert_eq!(host.hub.guests[0].uuid, 77);
        assert_eq!(host.hub.guests[0].health, 0.0);
        assert!(
            host.hub.guests[0].dead,
            "actual command death before request"
        );
        for _ in rx.try_iter() {}
        game.lan = Some(host);
        game.lan_guest_packet(7, S::ClientCommand(play::ClientCommand { action: 0 }));
        game.tick_server_travel();
        let host = game.lan.take().unwrap();
        assert!(
            !game.on_server_trip(7),
            "admitted lit columns permit actual arrival"
        );
        let guest = &host.hub.guests[0];
        assert_eq!(guest.uuid, 77);
        assert_eq!(guest.health, 20.0);
        assert!(!guest.dead);
        assert_eq!(guest.position, [12.5, 100.1, 12.5]);
        assert_eq!(game.level.world_spawn, Some([4, 100, 4]));
        assert_eq!(game.level.world_spawn_angle, [-30.0, -5.0]);
        assert_eq!(game.world.game_time, clock);
        let physical = [guest.yaw.to_bits(), guest.pitch.to_bits()];
        let awaiting_id = guest
            .awaiting_teleport
            .expect("actual final arrival awaits its acknowledgement")
            .0;
        let mut packets = Vec::new();
        for out in rx.try_iter() {
            match out {
                Out::Packet(p) => packets.push(p),
                Out::Packets(p) => packets.extend(p),
                Out::Disconnect(_) => panic!("unexpected disconnect"),
            }
        }
        let mut positions = Vec::new();
        let mut respawns = 0;
        for p in packets {
            println!("complete actual Hub frame {p:?}");
            let mut r = horizon_protocol::buf::Reader::new(&p);
            let id = r.varint().unwrap();
            match C::decode(id, r.rest()).unwrap() {
                C::PlayerPosition(p) => positions.push(p),
                C::Respawn(_) => respawns += 1,
                _ => {}
            }
        }
        assert_eq!(respawns, 1);
        assert!(!positions.is_empty());
        println!("all actual arrival positions {positions:?}");
        let selected: Vec<_> = positions
            .iter()
            .filter(|p| p.teleport == awaiting_id)
            .collect();
        assert_eq!(
            selected.len(),
            1,
            "select by actual authoritative pending id, never expected position/pitch"
        );
        let p = selected[0];
        assert_eq!(p.position, [12.5, 100.1, 12.5]);
        // All successful command/death/arrival/identity/world controls precede the intended regression.
        assert_eq!(
            (
                respawn.get("pitch"),
                physical,
                [p.yaw.to_bits(), p.pitch.to_bits()]
            ),
            (
                Some(&horizon_core::nbt::Tag::Float(10f32.to_bits())),
                [45f32.to_bits(), 10f32.to_bits()],
                [45f32.to_bits(), 10f32.to_bits()]
            )
        );
        drop(host);
        drop(game);
        std::fs::remove_dir_all(scratch).unwrap();
    }
}

#[cfg(test)]
mod pitch_preservation_controls {
    use super::*;

    #[test]
    fn wrapped_existing_callers_default_to_positive_zero_pitch() {
        let c = RespawnConfig::wrapped(Dim::Overworld, [5, 100, 5], 45.0, false);
        assert_eq!(c.yaw.to_bits(), 45f32.to_bits());
        assert_eq!(c.pitch.to_bits(), 0.0f32.to_bits());
        assert!(!c.forced);
    }

    /// Added source/model controls; these do not add a connected bed/anchor runtime claim.
    #[test]
    #[ignore = "prepared resources and isolated scratch homes/cwd"]
    fn bed_anchor_facing_and_invalid_personal_fallback_ignore_stored_pitch() {
        let mut resources = None;
        let mut game = crate::game::game_tests::tests::server_game(&mut resources);
        let stone = game
            .pack
            .assets
            .registry
            .default_state("minecraft:stone")
            .unwrap();
        for x in 0..16 {
            for z in 0..16 {
                game.world.set(x, 99, z, stone).unwrap();
            }
        }
        let state = |game: &Game<'_>, name: &str, properties: &[(&str, &str)]| {
            let registry = game.pack.assets.registry;
            let id = registry.default_state(name).unwrap();
            let mut value = registry.state(id).unwrap().clone();
            for (key, value_) in properties {
                value.properties.insert((*key).into(), (*value_).into());
            }
            registry.resolve(&value).unwrap()
        };
        let head = state(
            &game,
            "minecraft:red_bed",
            &[("facing", "north"), ("part", "head")],
        );
        let foot = state(
            &game,
            "minecraft:red_bed",
            &[("facing", "north"), ("part", "foot")],
        );
        game.world.set(5, 100, 5, head).unwrap();
        game.world.set(5, 100, 6, foot).unwrap();
        assert!(game.is_bed(head) && game.bed_sets_spawn(head));
        let bed = RespawnConfig {
            dim: Dim::Overworld,
            pos: [5, 100, 5],
            yaw: 45.0,
            pitch: 0.0,
            forced: true,
        };
        let zero = game
            .find_respawn_and_use(bed, false)
            .unwrap()
            .expect("valid bed geometry");
        let stored = game
            .find_respawn_and_use(RespawnConfig { pitch: 75.0, ..bed }, false)
            .unwrap()
            .unwrap();
        assert_eq!(stored, zero);
        assert_eq!(stored.2.to_bits(), 0.0f32.to_bits());
        assert_eq!(stored.1.to_bits(), look_at_yaw(stored.0, bed.pos).to_bits());

        // Existing built-in dimension facts select the anchor rule; no new world or actor API.
        game.dim = Dim::Nether;
        let anchor = state(&game, "minecraft:respawn_anchor", &[("charges", "2")]);
        game.world.set(10, 100, 10, anchor).unwrap();
        assert!(game.anchor_works() && game.is_anchor(anchor));
        let c = RespawnConfig {
            dim: Dim::Nether,
            pos: [10, 100, 10],
            yaw: 45.0,
            pitch: 0.0,
            forced: true,
        };
        let zero = game
            .find_respawn_and_use(c, false)
            .unwrap()
            .expect("valid anchor geometry");
        let stored = game
            .find_respawn_and_use(RespawnConfig { pitch: 75.0, ..c }, true)
            .unwrap()
            .unwrap();
        assert_eq!(stored, zero);
        assert_eq!(stored.2.to_bits(), 0.0f32.to_bits());
        assert_eq!(stored.1.to_bits(), look_at_yaw(stored.0, c.pos).to_bits());
        assert_eq!(
            game.world.block(10, 100, 10),
            anchor,
            "existing forced-charge behavior"
        );

        game.dim = Dim::Overworld;
        game.level.world_spawn = Some([4, 100, 4]);
        game.level.world_spawn_angle = [-30.0, -5.0];
        game.world.set(12, 100, 12, stone).unwrap();
        let invalid = RespawnConfig {
            dim: Dim::Overworld,
            pos: [12, 100, 12],
            yaw: 45.0,
            pitch: 10.0,
            forced: true,
        };
        game.respawn_config = Some(invalid);
        assert!(game.resolve_server_respawn(invalid).is_none());
        assert!(game.respawn_config.is_none());
        assert_eq!(game.level.world_spawn, Some([4, 100, 4]));
        assert_eq!(game.level.world_spawn_angle, [-30.0, -5.0]);
    }
}
