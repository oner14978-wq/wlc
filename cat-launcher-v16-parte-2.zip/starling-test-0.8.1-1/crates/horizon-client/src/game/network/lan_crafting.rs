//! Crafting for LAN guests: the inventory's 2x2 grid (window 0) and the
//! crafting table (`minecraft:crafting`) run the host's menu engine
//! (`horizon_client::menu`, `Kind::Inventory` / `Kind::Crafting`) over the
//! guest's inventory, with vanilla's packets: OpenScreen, container clicks
//! and their corrections, and the grid back into the inventory when the menu
//! closes (`AbstractContainerMenu.clearContainer`).
use super::Game;
use horizon_client::{
    containers::{BlockEntity, ModMenuType},
    furnace::FurnaceCooking,
    items::ItemStack,
    lan::{
        guest::Guest,
        menu::{ModCraft, Slots, linked_slot_count, read_links, write_links},
    },
    menu::{
        Env, Input, Kind, Menu,
        place::{PostPlace, TransferError},
    },
};
use horizon_protocol::packets::play::{self, Clientbound as C};

/// `AbstractContainerMenu.dropOrPlaceInInventory`: actual network disconnects
/// drop inputs; a live close still returns them to the inventory.
#[derive(Clone, Copy, PartialEq, Eq)]
pub(super) enum MenuRemoval {
    Live,
    Disconnected,
}

/// The guest's menus the game runs: kept between clicks, so a drag (quick
/// craft) spans them as in vanilla.
#[derive(Default)]
pub(super) struct GuestCrafting {
    /// The inventory menu; its grid lives in the hub's guest.
    inventory: Option<Box<Menu>>,
    /// The open crafting table: its window, state id, menu and block.
    pub(super) table: Option<(i32, i32, Box<Menu>, [i32; 3])>,
    /// The open furnace's or brewing stand's window and menu (`AbstractFurnaceMenu`,
    /// `BrewingStandMenu`); its slots live in the block entity and the hub's
    /// container menu keeps the client in sync.
    pub(super) machine: Option<(i32, Box<Menu>)>,
}

/// The most containers `native_recipe_sources` adds to one placement.
const MAX_RECIPE_SOURCES: usize = 64;
/// The most containers `native_menu_links` links one menu's slots to.
const MAX_MENU_LINKS: usize = 64;

/// ServerboundContainerClickPacket's input.
pub(super) fn input(id: i32) -> Input {
    match id {
        0 => Input::Pickup,
        1 => Input::QuickMove,
        2 => Input::Swap,
        3 => Input::Clone,
        4 => Input::Throw,
        5 => Input::QuickCraft,
        _ => Input::PickupAll,
    }
}

/// The armor's player-container slots, head to feet (`Inventory` 39..36).
const ARMOR: [usize; 4] = [39, 38, 37, 36];
const OFFHAND: usize = 40;

/// The guest's inventory, armor, off hand, selection and carried stack into `menu`.
pub(super) fn load_player(menu: &mut Menu, g: &Guest) {
    for i in 0..36 {
        menu.set_player_item(i, g.inventory[i].clone());
    }
    for (k, slot) in ARMOR.into_iter().enumerate() {
        menu.set_player_item(slot, g.armor[k].clone());
    }
    menu.set_player_item(OFFHAND, g.offhand.clone());
    menu.selected = g.selected;
    menu.creative = g.creative();
    menu.levels = g.xp_level;
    menu.carried = g.carried.clone();
}

/// The vanilla menu engine's kind for a guest's menu over block entity `entity`, with the
/// container's slots: a furnace's, a brewing stand's, a crafter's, or a content mod's menu type
/// with its slots' rules. None for the others, whose clicks the hub runs.
pub(super) fn machine_menu(
    entity: &BlockEntity,
    mod_type: Option<&'static horizon_client::containers::ModMenuType>,
) -> Option<(Kind, Vec<Option<ItemStack>>)> {
    Some(match entity {
        BlockEntity::Furnace(f) => {
            let recipe = match f.kind.recipe_type() {
                "minecraft:blasting" => "blasting",
                "minecraft:smoking" => "smoking",
                _ => "smelting",
            };
            (Kind::Furnace(recipe), f.items.to_vec())
        }
        BlockEntity::Brewing(b) => (Kind::Brewing, b.items.to_vec()),
        BlockEntity::Crafter(c) => (Kind::CrafterBlock, c.items.to_vec()),
        BlockEntity::Mod(m) => {
            let t = mod_type?;
            let mut items = m.items.clone();
            items.resize(t.slots, None);
            (Kind::Mod(t), items)
        }
        _ => return None,
    })
}

/// `load_player` back.
pub(super) fn store_player(menu: &mut Menu, g: &mut Guest) {
    for i in 0..36 {
        g.inventory[i] = menu.player_item(i).cloned();
    }
    for (k, slot) in ARMOR.into_iter().enumerate() {
        g.armor[k] = menu.player_item(slot).cloned();
    }
    g.offhand = menu.player_item(OFFHAND).cloned();
    g.carried = menu.carried.take();
}

/// Inventory.placeItemBackInInventory for each stack: what doesn't fit is
/// left for Player.drop (creative players keep it too).
fn place_back(menu: &mut Menu, env: &Env, stacks: Vec<ItemStack>) {
    menu.creative = false;
    for mut stack in stacks {
        menu.give(env, &mut stack);
        if stack.count > 0 {
            menu.dropped.push(stack);
        }
    }
}

impl Game<'_> {
    /// `LocalPlayer.doLimitedCrafting`: whether limited crafting is active.
    pub fn limited_crafting(&self) -> bool {
        self.remote.as_ref().map_or_else(
            || {
                self.ui
                    .rules
                    .bool_at(horizon_client::gamerules::vanilla::LIMITED_CRAFTING)
            },
            |r| r.do_limited_crafting,
        )
    }

    pub(super) fn menu_env(&self) -> Env<'_> {
        Env {
            crafting_remainder: Some(self),
            player: self
                .lan_acting_uuid
                .or_else(|| self.remote.as_ref().map(|r| r.profile())),
            player_entity_id: Some(self.own_entity_id()),
            loop_context: &self.loop_context,
            items: self.items(),
            recipes: self.recipes(),
            brewing: &self.stations().brewing,
            banners: &self.stations().banners,
            station_recipes: &self.stations().recipes,
            enchantments: &self.stations().enchantments,
            names: &self.pack.names,
            trade: None,
            maps: None,
            limited_crafting: self.limited_crafting(),
            known_recipes: Some(&self.level.recipe_book),
        }
    }

    /// Runs `op` on the guest's menu with their inventory copied in and back.
    pub(super) fn guest_menu_op<R>(
        &mut self,
        gi: usize,
        menu: &mut Menu,
        op: impl FnOnce(&mut Menu, &Env) -> R,
    ) -> Option<R> {
        self.lan.as_ref()?;
        // Crafting and cartography read and derive this level's saved maps.
        let maps = matches!(
            menu.kind(),
            Kind::Cartography | Kind::Crafting | Kind::Inventory
        )
        .then(|| {
            let g = &self.lan.as_ref().unwrap().hub.guests[gi];
            (0..menu.slot_count())
                .filter_map(|s| menu.slot(s).cloned())
                .chain(g.inventory.iter().flatten().cloned())
                .chain(g.carried.clone())
                .collect::<Vec<_>>()
        })
        .filter(|held| {
            menu.kind() == Kind::Cartography
                || held
                    .iter()
                    .filter_map(super::maps::map_id)
                    .any(|id| self.map(id).is_some())
        })
        .map(|held| self.level_maps(&held));
        let host = self.lan.as_ref()?;
        let env = Env {
            crafting_remainder: Some(self),
            player: Some(host.hub.guests[gi].uuid),
            player_entity_id: Some(host.hub.guests[gi].entity_id),
            loop_context: &self.loop_context,
            maps: maps.as_ref().map(|m| m as &dyn horizon_client::menu::Maps),
            limited_crafting: host.hub.limited_crafting,
            known_recipes: Some(&host.hub.guests[gi].recipe_book),
            ..self.menu_env()
        };
        let limits = host.hub.guests[gi]
            .menu
            .as_ref()
            .map(|opened| opened.slots.stack_limits(&self.world, opened.size))
            .unwrap_or_default();
        menu.set_container_limits(limits);
        load_player(menu, &host.hub.guests[gi]);
        menu.brewed_potion_hook = !mod_api::__private::mods().is_empty();
        menu.item_smelted_hook = menu.brewed_potion_hook;
        let result = op(menu, &env);
        if let Some(maps) = maps {
            self.register_made_maps(maps);
        }
        // A taken anvil result waits for AnvilCraftEvent.Pre: what the click
        // dropped waits with it (lan_station_op throws it or refuses the take).
        let dropped = if menu.anvil_craft.is_some() {
            Vec::new()
        } else {
            std::mem::take(&mut menu.dropped)
        };
        let equipped = std::mem::take(&mut menu.equipped);
        let brewed = std::mem::take(&mut menu.brewed);
        let brewed_potion_takes = std::mem::take(&mut menu.brewed_potion_takes);
        let crafted = std::mem::take(&mut menu.crafted);
        let item_crafted = std::mem::take(&mut menu.item_crafted);
        menu.drops.clear();
        let host = self.lan.as_mut()?;
        host.hub
            .guests
            .update(gi, |guest| store_player(menu, guest));
        let guest = &host.hub.guests[gi];
        let (conn, uuid, entity_id) = (guest.conn, guest.uuid, guest.entity_id);
        if !brewed.is_empty() || !brewed_potion_takes.is_empty() {
            self.as_guest(conn, |g| {
                for stack in &brewed_potion_takes {
                    g.native_player_brewed_potion(uuid, entity_id, stack);
                }
                for stack in &brewed {
                    g.trigger_brewed_potion(stack);
                }
            });
        }
        if !crafted.is_empty() {
            self.as_guest(conn, |g| {
                for (recipe, ingredients) in &crafted {
                    g.trigger_recipe_crafted(recipe, ingredients);
                }
            });
        }
        if !item_crafted.is_empty() {
            self.as_guest(conn, |g| {
                let player = g.native_acting_id();
                for (recipe, stack) in &item_crafted {
                    g.native_item_crafted(player, recipe, stack);
                }
            });
        }
        if !equipped.is_empty() {
            self.as_guest(conn, |g| {
                for (slot, stack) in equipped {
                    g.player_equipped(slot, stack.as_ref());
                }
            });
        }
        self.drop_guest_items(gi, dropped);
        Some(result)
    }

    /// `InventoryMenu.slotsChanged` for guest `uuid`'s crafting grid written outside a click
    /// (a mod's menu slot write, at the root commit): the result made again from the grid, with
    /// `native_prepare_item_craft` as a click has it, kept by the guest and their menu. The
    /// client hears it with the tick's inventory sync.
    pub(super) fn guest_craft_result(&mut self, conn: u32) {
        let Some(g) = self
            .lan
            .as_ref()
            .and_then(|host| host.hub.guest(conn).filter(|g| g.placed))
        else {
            return;
        };
        let uuid = g.uuid;
        let mut result = self
            .recipes()
            .find(&self.loop_context, &g.craft_grid, 2)
            .map(|(_, stack)| stack);
        if mod_api::__private::listened(mod_api::HookId::PrepareItemCraft) {
            let name = g.name.clone();
            self.native_prepare_item_craft(uuid, &name, None, &mut result);
        }
        let Some(host) = self.lan.as_mut() else {
            return;
        };
        if host
            .hub
            .update_guest(conn, |g| g.craft_result.clone_from(&result))
            .is_none()
        {
            return;
        }
        let menu = host
            .play
            .get_mut(&conn)
            .and_then(|p| p.crafting.inventory.take());
        if let Some(mut menu) = menu {
            menu.set_slot(&self.menu_env(), 0, result);
            if let Some(play) = self.lan.as_mut().and_then(|host| host.play.get_mut(&conn)) {
                play.crafting.inventory = Some(menu);
            }
        }
    }

    /// A click on the guest's inventory menu (window 0): `InventoryMenu`,
    /// crafting grid included. False for other windows.
    pub(super) fn lan_inventory_click(&mut self, conn: u32, p: &play::ContainerClick) -> bool {
        if p.container != 0 {
            return false;
        }
        let Some(host) = self.lan.as_mut() else {
            return true;
        };
        let Some(gi) = host.hub.guests.iter().position(|g| g.conn == conn) else {
            return true;
        };
        if host.hub.guests[gi].spectator() {
            return true;
        }
        let crafting = host.play.entry(conn).or_default();
        let mut menu = crafting
            .crafting
            .inventory
            .take()
            .unwrap_or_else(|| Box::new(Menu::new(Kind::Inventory)));
        let grid = host.hub.guests[gi].craft_grid.clone();
        let Some(changed) = self.guest_menu_op(gi, &mut menu, |menu, env| {
            for (k, s) in grid.into_iter().enumerate() {
                menu.set_slot(env, 1 + k, s);
            }
            let before: Vec<_> = (0..menu.slot_count())
                .map(|s| menu.slot(s).cloned())
                .collect();
            let _ = menu.click(env, i32::from(p.slot), i32::from(p.button), input(p.input));
            (0..menu.slot_count())
                .filter(|&s| menu.slot(s) != before[s].as_ref())
                .collect::<Vec<_>>()
        }) else {
            return true;
        };
        let Some(host) = self.lan.as_ref() else {
            return true;
        };
        let guest = &host.hub.guests[gi];
        let (uuid, name) = (guest.uuid, guest.name.clone());
        let mut result = menu.slot(0).cloned();
        self.native_prepare_item_craft(uuid, &name, None, &mut result);
        let env = self.menu_env();
        menu.set_slot(&env, 0, result);
        let Some(host) = self.lan.as_mut() else {
            return true;
        };
        host.hub.guests.update(gi, |g| {
            for k in 0..4 {
                g.craft_grid[k] = menu.slot(1 + k).cloned();
            }
            g.craft_result = menu.slot(0).cloned();
        });
        host.play.entry(conn).or_default().crafting.inventory = Some(menu);
        host.hub.inventory_clicked(conn, p, &self.world, &changed);
        true
    }

    /// A click on the guest's open furnace, blast furnace, smoker or brewing stand:
    /// the host's `AbstractFurnaceMenu` (fuel slot, take-only result, quick moves by
    /// recipe and fuel), `BrewingStandMenu` (one bottle per slot, ingredient and
    /// blaze powder slots) or a content mod's menu type (`Kind::Mod`) over the
    /// block entity's slots. False for other windows.
    pub(super) fn lan_machine_click(&mut self, conn: u32, p: &play::ContainerClick) -> bool {
        let Some(host) = self.lan.as_mut() else {
            return false;
        };
        let Some(gi) = host.hub.guests.iter().position(|g| g.conn == conn) else {
            return false;
        };
        let Some((pos, mod_type, hidden, menu_id)) = host.hub.guests[gi]
            .menu
            .as_ref()
            .filter(|m| p.container != 0 && m.window == p.container)
            .and_then(|m| match m.slots {
                Slots::Block(pos) => Some((
                    pos,
                    m.mod_type,
                    m.hidden.clone(),
                    host.hub.registry_name("minecraft:menu", m.kind)?.to_owned(),
                )),
                _ => None,
            })
        else {
            return false;
        };
        // A mod menu type's linked slots show their containers' slots
        // (`native_menu_links`); those with nothing behind them are left out
        // of the click, as a hidden slot is.
        let linked = mod_type.and_then(|t| t.links).map(|l| {
            let links = host.hub.guests[gi]
                .menu
                .as_ref()
                .map(|m| m.links.clone())
                .unwrap_or_default();
            (l, links)
        });
        let mut hidden = hidden;
        if let Some((l, links)) = &linked {
            let bound = linked_slot_count(&self.world, links);
            hidden.extend(l.slots().skip(bound));
        }
        let Some((kind, mut items)) = self
            .world
            .block_entities
            .get(&pos)
            .and_then(|entity| machine_menu(entity, mod_type))
        else {
            return false;
        };
        if let Some((l, links)) = &linked {
            for (k, stack) in l.slots().zip(
                read_links(&self.world, links, l.count)
                    .into_iter()
                    .chain(std::iter::repeat(None)),
            ) {
                items[k] = stack;
            }
        };
        let furnace = matches!(kind, Kind::Furnace(_));
        // CrafterBlockEntity.containerData: the disabled slots, then triggered.
        let crafter_data = match self.world.block_entities.get(&pos) {
            Some(BlockEntity::Crafter(c)) => Some((c.disabled, c.triggered)),
            _ => None,
        };
        if host.hub.guests[gi].spectator() {
            // handleContainerClick: nothing changes, and sendAllDataToRemote
            // takes back what the client predicted.
            host.hub.resend_menu(conn, p.container, &self.world);
            return true;
        }
        let mut menu = host
            .play
            .entry(conn)
            .or_default()
            .crafting
            .machine
            .take()
            .filter(|(window, m)| *window == p.container && m.kind() == kind)
            .map_or_else(|| Box::new(Menu::new(kind)), |(_, m)| m);
        menu.set_registry_id(Some(&menu_id));
        for &slot in &hidden {
            menu.hide_slot(slot);
        }
        // A crafting grid's result is what the guest was shown, the mods' say
        // included, while the grid is as it was then.
        let shown = Self::lan_mod_craft_shown(self.lan.as_ref().unwrap(), gi, &items);
        let Some(mut changed) = self.guest_menu_op(gi, &mut menu, |menu, env| {
            if matches!(kind, Kind::Mod(_)) {
                menu.load_container(env, &items);
                if let Some((slot, result)) = shown {
                    menu.set_slot(env, slot, result);
                }
            } else {
                for (k, s) in items.iter().enumerate() {
                    menu.set_slot(env, k, s.clone());
                }
            }
            // After the slots: setting a disabled slot (CrafterBlockEntity.setItem) enables it.
            if let Some((disabled, triggered)) = crafter_data {
                for (k, d) in disabled.iter().enumerate() {
                    menu.data[k] = i32::from(*d);
                }
                menu.data[9] = i32::from(triggered);
            }
            let before: Vec<_> = (0..menu.slot_count())
                .map(|s| menu.slot(s).cloned())
                .collect();
            let _ = menu.click(env, i32::from(p.slot), i32::from(p.button), input(p.input));
            (0..menu.slot_count())
                .filter(|&s| menu.slot(s) != before[s].as_ref())
                .collect::<Vec<_>>()
        }) else {
            return true;
        };
        let mut linked_after = Vec::new();
        match self.world.block_entities.get_mut(&pos) {
            Some(BlockEntity::Furnace(f)) => {
                for k in 0..3 {
                    f.items[k] = menu.slot(k).cloned();
                }
                // AbstractFurnaceBlockEntity.setItem: only a new input restarts cooking.
                f.input_clicked(&self.loop_context, world_recipes!(self), items[0].clone());
            }
            // BrewingStandBlockEntity.serverTick notices a new ingredient itself.
            Some(BlockEntity::Brewing(b)) => {
                for k in 0..5 {
                    b.items[k] = menu.slot(k).cloned();
                }
            }
            // The mod's items past its menu's slots stay as they were.
            Some(BlockEntity::Mod(m)) => {
                let n = items.len();
                if m.items.len() < n {
                    m.items.resize(n, None);
                }
                let mut after = menu.container_items();
                // Linked slots go back to their containers, never into the
                // block entity.
                if let Some((l, _)) = &linked {
                    linked_after = l
                        .slots()
                        .filter_map(|k| after.get_mut(k).map(Option::take))
                        .collect();
                }
                for (slot, stack) in m.items.iter_mut().zip(after) {
                    *slot = stack;
                }
            }
            // CrafterBlockEntity.setItem: filling a disabled slot enables it.
            Some(BlockEntity::Crafter(c)) => {
                for k in 0..9 {
                    c.items[k] = menu.slot(k).cloned();
                    c.disabled[k] = menu.data[k] == 1;
                }
            }
            _ => {}
        }
        // FurnaceResultSlot.checkTakeAchievements, each as the click made it.
        let Some(guest) = self.lan.as_ref().map(|host| &host.hub.guests[gi]) else {
            return true;
        };
        let (uuid, entity_id, at) = (guest.uuid, guest.entity_id, guest.position);
        for (stack, removed) in std::mem::take(&mut menu.item_smelted) {
            self.native_item_smelted(uuid, entity_id, stack.as_ref(), removed);
        }
        // The guest took from the output.
        let count = |s: Option<&ItemStack>| s.map_or(0, |s| s.count);
        if furnace && count(menu.slot(2)) < count(items[2].as_ref()) {
            let output = items[2].as_ref();
            if let Some(output) = output
                && mod_api::__private::listened(mod_api::HookId::FurnaceExtract)
                && let Some(name) = self
                    .lan
                    .as_ref()
                    .map(|host| host.hub.guests[gi].name.clone())
            {
                let taken = output.count - count(menu.slot(2));
                self.native_furnace_extract(
                    uuid,
                    &name,
                    [pos.0, pos.1, pos.2],
                    &output.item,
                    taken,
                );
            }
            self.award_furnace_recipes(pos, at);
        }
        // Slot.setChanged on a changed container slot: BlockEntity.setChanged,
        // so the chunk is saved and comparators read the block again.
        if changed.iter().any(|&s| s < items.len()) {
            self.container_changed(pos);
        }
        if let Some((l, links)) = &linked {
            let bound = linked_slot_count(&self.world, links).min(l.count);
            linked_after.truncate(bound);
            for at in write_links(&mut self.world, links, linked_after) {
                self.container_changed(at);
            }
        }
        if let Some(slot) = self.lan_mod_craft_settle(gi, pos, &mut menu)
            && !changed.contains(&slot)
        {
            changed.push(slot);
        }
        if let Some(host) = self.lan.as_mut() {
            host.play.entry(conn).or_default().crafting.machine = Some((p.container, menu));
            host.hub.inventory_clicked(conn, p, &self.world, &changed);
        }
        true
    }

    /// `ServerGamePacketListenerImpl.handleContainerSlotStateChanged`: a
    /// guest's crafter slot toggle (`CrafterBlockEntity.setSlotState`) in
    /// their open crafter window.
    pub(super) fn lan_crafter_slot_state(
        &mut self,
        conn: u32,
        window: i32,
        slot: i32,
        enabled: bool,
    ) {
        let Some(host) = self.lan.as_ref() else {
            return;
        };
        let Some(pos) = host
            .hub
            .guest(conn)
            .filter(|g| !g.spectator())
            .and_then(|g| g.menu.as_ref())
            .filter(|m| window != 0 && m.window == window)
            .and_then(|m| match m.slots {
                Slots::Block(pos) => Some(pos),
                _ => None,
            })
        else {
            return;
        };
        if let (Some(BlockEntity::Crafter(c)), Ok(slot)) = (
            self.world.block_entities.get_mut(&pos),
            usize::try_from(slot),
        ) {
            c.set_slot_state(slot, enabled);
            self.world.modified.insert((pos.0 >> 4, pos.2 >> 4));
        }
    }

    /// ServerGamePacketListenerImpl.handlePlaceRecipe: the guest's recipe
    /// book places a known recipe in their inventory grid, crafting table or furnace
    /// (`ServerPlaceRecipe`), and answers with a ghost recipe when the items
    /// are missing.
    pub(super) fn lan_place_recipe(
        &mut self,
        conn: u32,
        p: &horizon_protocol::packets::recipes::PlaceRecipe,
    ) {
        let Some(host) = self.lan.as_ref() else {
            return;
        };
        let Some(gi) = host.hub.guests.iter().position(|g| g.conn == conn) else {
            return;
        };
        let g = &host.hub.guests[gi];
        if g.spectator() {
            return;
        }
        // The server menu uses the world's active data-pack tables, the same
        // tables used by the guest menu below. The base resources can have a
        // different display registry or placement for an overridden recipe.
        let Some(id) = world_stations!(self)
            .recipe_index
            .recipe_of_display(p.recipe)
            .map(str::to_owned)
        else {
            return;
        };
        // An unknown or impossible recipe is refused outright.
        if !g.recipe_book.knows(&id)
            || world_recipes!(self)
                .placement(&id)
                .is_none_or(|placement| placement.impossible())
        {
            return;
        }
        let (player, name, creative) = (g.uuid, g.name.clone(), g.creative());
        self.native_player_recipe_book_click(player, &name, &id, p.use_max);
        // A mod menu type's crafting grid places as a crafting table's.
        if self.lan_mod_crafting_window(gi, p.container).is_some() {
            let placed = self.lan_mod_craft_apply(gi, p.container, |menu, env| {
                menu.place_recipe(env, &id, p.use_max, creative, None)
            });
            if placed == Some(PostPlace::Ghost) {
                self.lan
                    .as_mut()
                    .unwrap()
                    .hub
                    .send_ghost_recipe(conn, p.container, &id);
            }
            return;
        }
        // AbstractFurnaceMenu.handlePlacement: the current furnace's slots,
        // rather than the separate crafting-table menu, own cooking inputs.
        let furnace = self.lan.as_ref().unwrap().hub.guests[gi]
            .menu
            .as_ref()
            .filter(|m| p.container != 0 && m.window == p.container)
            .and_then(|m| match m.slots {
                Slots::Block(pos) => Some(pos),
                _ => None,
            })
            .and_then(|pos| match self.world.block_entities.get(&pos) {
                Some(BlockEntity::Furnace(f)) => {
                    let recipe = match f.kind.recipe_type() {
                        "minecraft:blasting" => "blasting",
                        "minecraft:smoking" => "smoking",
                        _ => "smelting",
                    };
                    Some((pos, Kind::Furnace(recipe), f.items.clone()))
                }
                _ => None,
            });
        let placed = if let Some((pos, kind, items)) = furnace {
            // Opening need not have created the click/drag cache yet.
            let mut menu = self
                .lan
                .as_mut()
                .unwrap()
                .play
                .entry(conn)
                .or_default()
                .crafting
                .machine
                .take()
                .filter(|(window, m)| *window == p.container && m.kind() == kind)
                .map_or_else(|| Box::new(Menu::new(kind)), |(_, m)| m);
            let placed = self.guest_menu_op(gi, &mut menu, |menu, env| {
                for (k, item) in items.iter().enumerate() {
                    menu.set_slot(env, k, item.clone());
                }
                menu.place_recipe(env, &id, p.use_max, creative, None)
            });
            let changed = (0..3).any(|k| menu.slot(k) != items[k].as_ref());
            if let Some(BlockEntity::Furnace(f)) = self.world.block_entities.get_mut(&pos) {
                for k in 0..3 {
                    f.items[k] = menu.slot(k).cloned();
                }
                f.input_clicked(&self.loop_context, world_recipes!(self), items[0].clone());
            }
            if changed {
                self.container_changed(pos);
            }
            self.lan
                .as_mut()
                .unwrap()
                .play
                .entry(conn)
                .or_default()
                .crafting
                .machine = Some((p.container, menu));
            // Hub::sync_containers broadcasts the actual changed slots.
            placed
        } else {
            self.lan_apply_recipe(gi, p.container, |menu, env| {
                menu.place_recipe(env, &id, p.use_max, creative, None)
            })
        };
        if placed == Some(PostPlace::Ghost)
            && let Some(host) = self.lan.as_mut()
        {
            host.hub.send_ghost_recipe(conn, p.container, &id);
        }
    }

    pub(super) fn guest_recipe_transfer(&mut self, conn: u32, data: &[u8]) {
        use horizon_protocol::buf::Writer;
        let Some(host) = self.lan.as_ref() else {
            return;
        };
        let Some(gi) = host.hub.guests.iter().position(|g| g.conn == conn) else {
            return;
        };
        let g = &host.hub.guests[gi];
        if g.brand != "horizon" || g.spectator() {
            return;
        }
        let Ok((container, id, all)) = horizon_client::lan::recipes::decode_transfer_request(data)
        else {
            return;
        };
        let result = if container == 0 && (g.menu.is_some() || g.creative()) {
            Err(TransferError::Unavailable)
        } else {
            self.lan_apply_recipe(gi, container, |menu, env| {
                menu.transfer_recipe(env, &id, all)
            })
            .unwrap_or(Err(TransferError::Unavailable))
        };
        let mut reply = Writer::new();
        reply.varint(container);
        reply.u8(match result {
            Ok(()) => 0,
            Err(TransferError::Missing) => 1,
            Err(TransferError::NoRoom) => 2,
            Err(TransferError::Unavailable) => 3,
        });
        if let Some(host) = self.lan.as_ref() {
            host.hub.guests[gi].send(&C::CustomPayload(
                horizon_protocol::packets::configuration::CustomPayload {
                    channel: horizon_client::lan::recipes::TRANSFER_CHANNEL.into(),
                    data: reply.data,
                },
            ));
        }
    }

    fn lan_apply_recipe<R>(
        &mut self,
        gi: usize,
        container: i32,
        apply: impl FnOnce(&mut Menu, &Env) -> R,
    ) -> Option<R> {
        if self.lan_mod_crafting_window(gi, container).is_some() {
            return self.lan_mod_craft_apply(gi, container, apply);
        }
        let conn = self.lan.as_ref()?.hub.guests[gi].conn;
        let host = self.lan.as_mut()?;
        let placed = if container == 0 {
            let crafting = host.play.entry(conn).or_default();
            let mut menu = crafting
                .crafting
                .inventory
                .take()
                .unwrap_or_else(|| Box::new(Menu::new(Kind::Inventory)));
            let grid = host.hub.guests[gi].craft_grid.clone();
            let placed = self.guest_menu_op(gi, &mut menu, |menu, env| {
                for (k, s) in grid.into_iter().enumerate() {
                    menu.set_slot(env, 1 + k, s);
                }
                apply(menu, env)
            })?;
            let host = self.lan.as_mut()?;
            host.hub.guests.update(gi, |g| {
                for k in 0..4 {
                    g.craft_grid[k] = menu.slot(1 + k).cloned();
                }
                g.craft_result = menu.slot(0).cloned();
            });
            host.play.entry(conn).or_default().crafting.inventory = Some(menu);
            host.hub.send_inventory(gi);
            placed
        } else {
            let (window, state, mut menu, pos) = host
                .play
                .get_mut(&conn)
                .and_then(|play| play.crafting.table.take_if(|(w, ..)| *w == container))?;
            let placed = self.guest_menu_op(gi, &mut menu, apply)?;
            let host = self.lan.as_mut()?;
            host.play.entry(conn).or_default().crafting.table = Some((window, state, menu, pos));
            self.lan_send_table_content(conn);
            placed
        };
        Some(placed)
    }

    /// The guest opened a crafting table (`CraftingTableBlock.getMenuProvider`).
    pub(super) fn lan_open_crafting(&mut self, conn: u32, pos: [i32; 3]) {
        if !self.guest_may_open(conn, "minecraft:crafting", Some(pos)) {
            return;
        }
        // ServerPlayer.openMenu closes the menu that was open.
        self.guest_close_all(conn);
        let Some(host) = self.lan.as_mut() else {
            return;
        };
        let title = horizon_protocol::text::translatable("container.crafting", &[]);
        let Some(window) = host.hub.open_window(conn, "minecraft:crafting", title) else {
            return;
        };
        let mut menu = Box::new(Menu::new(Kind::Crafting));
        menu.set_registry_id(Some("minecraft:crafting"));
        host.play.entry(conn).or_default().crafting.table = Some((window, 0, menu, pos));
        self.lan_send_table_content(conn);
    }

    /// A click on the guest's crafting table window; false for other windows.
    pub(super) fn lan_crafting_click(&mut self, conn: u32, p: &play::ContainerClick) -> bool {
        let Some(host) = self.lan.as_mut() else {
            return false;
        };
        let Some(play) = host.play.get_mut(&conn) else {
            return false;
        };
        let Some((window, state, mut menu, pos)) = play
            .crafting
            .table
            .take_if(|(window, ..)| *window == p.container)
        else {
            return false;
        };
        // handleContainerClick: broadcastFullState only for a click on an old
        // state, else only what the client got wrong. The whole menu after every
        // click would undo the clicks it has predicted since.
        let mut agreed = false;
        // A table that is no longer valid takes no clicks (handleContainerClick).
        let gi = host.hub.guests.iter().position(|g| g.conn == conn);
        let Some(host) = self.lan.as_ref() else {
            return false;
        };
        if let Some(gi) = gi
            && !host.hub.guests[gi].spectator()
            && self.lan_table_valid(&host.hub.guests[gi], pos)
        {
            let Some(mut changed) = self.guest_menu_op(gi, &mut menu, |menu, env| {
                let before: Vec<_> = (0..menu.slot_count())
                    .map(|s| menu.slot(s).cloned())
                    .collect();
                let _ = menu.click(env, i32::from(p.slot), i32::from(p.button), input(p.input));
                (0..menu.slot_count())
                    .filter(|&s| menu.slot(s) != before[s].as_ref())
                    .collect::<Vec<_>>()
            }) else {
                return true;
            };
            let Some(guest) = self.lan.as_ref().map(|host| &host.hub.guests[gi]) else {
                return true;
            };
            let (uuid, name) = (guest.uuid, guest.name.clone());
            let mut result = menu.slot(0).cloned();
            let vanilla = result.clone();
            self.native_prepare_item_craft(uuid, &name, Some(pos), &mut result);
            if result != vanilla && !changed.contains(&0) {
                changed.push(0);
            }
            let env = self.menu_env();
            menu.set_slot(&env, 0, result);
            let Some(host) = self.lan.as_mut() else {
                return true;
            };
            agreed = p.state == state
                && host.hub.click_agreed(
                    gi,
                    p,
                    menu.slot_count(),
                    &|s| menu.slot(s).cloned(),
                    &changed,
                );
            if agreed {
                // The inventory menu's sync isn't to send what the click settled.
                host.hub.guests.update(gi, |g| {
                    for &s in changed.iter().filter(|&&s| s >= 10) {
                        g.menu_sent[s - 1] = menu.slot(s).cloned();
                    }
                });
            }
        }
        let Some(host) = self.lan.as_mut() else {
            return true;
        };
        host.play.entry(conn).or_default().crafting.table = Some((window, state, menu, pos));
        if !agreed {
            self.lan_send_table_content(conn);
        }
        true
    }

    /// `CraftingMenu.stillValid`: the block is still a crafting table and the
    /// guest is within reach of it.
    pub(super) fn lan_table_valid(&self, g: &Guest, pos: [i32; 3]) -> bool {
        let name = &self
            .res
            .facts()
            .get(self.world.block(pos[0], pos[1], pos[2]))
            .name;
        &**name == "minecraft:crafting_table" && g.within_block_range(pos, 4.0)
    }

    /// Guest `gi`'s open window `container` when it is a mod menu type with a
    /// crafting grid: its block and its type.
    fn lan_mod_crafting_window(
        &self,
        gi: usize,
        container: i32,
    ) -> Option<((i32, i32, i32), &'static ModMenuType)> {
        let host = self.lan.as_ref()?;
        let m = host.hub.guests[gi]
            .menu
            .as_ref()
            .filter(|m| container != 0 && m.window == container)?;
        let Slots::Block(pos) = m.slots else {
            return None;
        };
        let t = m.mod_type.filter(|t| t.crafting.is_some())?;
        matches!(self.world.block_entities.get(&pos), Some(BlockEntity::Mod(e)) if !e.id().is_empty())
            .then_some((pos, t))
    }

    /// `apply` (a recipe book placement or a viewer's transfer) on guest
    /// `gi`'s open mod crafting menu `container`, over its block entity's
    /// slots as a click is; None when that window is no such menu. Changes
    /// reach the guest with the tick's container sync.
    fn lan_mod_craft_apply<R>(
        &mut self,
        gi: usize,
        container: i32,
        apply: impl FnOnce(&mut Menu, &Env) -> R,
    ) -> Option<R> {
        let (pos, t) = self.lan_mod_crafting_window(gi, container)?;
        let Some(BlockEntity::Mod(m)) = self.world.block_entities.get(&pos) else {
            return None;
        };
        let mut items = m.items.clone();
        items.resize(t.slots, None);
        let host = self.lan.as_mut()?;
        let conn = host.hub.guests[gi].conn;
        let kind = Kind::Mod(t);
        let mut menu = host
            .play
            .entry(conn)
            .or_default()
            .crafting
            .machine
            .take()
            .filter(|(window, m)| *window == container && m.kind() == kind)
            .map_or_else(|| Box::new(Menu::new(kind)), |(_, m)| m);
        let shown = Self::lan_mod_craft_shown(self.lan.as_ref()?, gi, &items);
        let sources = self.lan_recipe_sources(gi, t, pos);
        menu.sources = sources.iter().map(|(_, items)| items.clone()).collect();
        let out = self.guest_menu_op(gi, &mut menu, |menu, env| {
            menu.load_container(env, &items);
            if let Some((slot, result)) = shown {
                menu.set_slot(env, slot, result);
            }
            apply(menu, env)
        })?;
        for ((at, before), after) in sources.into_iter().zip(std::mem::take(&mut menu.sources)) {
            if after == before {
                continue;
            }
            match self.world.block_entities.get_mut(&at) {
                Some(BlockEntity::Chest(items)) => *items = after,
                Some(BlockEntity::Mod(m)) => {
                    for (slot, stack) in m.items.iter_mut().zip(after) {
                        *slot = stack;
                    }
                }
                _ => {}
            }
            self.container_changed(at);
        }
        let after = menu.container_items();
        if after != items {
            if let Some(BlockEntity::Mod(m)) = self.world.block_entities.get_mut(&pos) {
                if m.items.len() < after.len() {
                    m.items.resize(after.len(), None);
                }
                for (slot, stack) in m.items.iter_mut().zip(after) {
                    *slot = stack;
                }
            }
            self.container_changed(pos);
        }
        self.lan_mod_craft_settle(gi, pos, &mut menu);
        self.lan
            .as_mut()?
            .play
            .entry(conn)
            .or_default()
            .crafting
            .machine = Some((container, menu));
        Some(out)
    }

    /// The containers recipe placement into guest `gi`'s mod crafting menu
    /// `t` at `pos` may also take from (`native_recipe_sources`): each block
    /// and its slots, chest-like or a mod's container, none twice, not `pos`.
    pub(super) fn lan_recipe_sources(
        &mut self,
        gi: usize,
        t: &ModMenuType,
        pos: (i32, i32, i32),
    ) -> Vec<((i32, i32, i32), Vec<Option<ItemStack>>)> {
        let mut asked = Vec::new();
        let Some(uuid) = self.lan.as_ref().map(|host| host.hub.guests[gi].uuid) else {
            return Vec::new();
        };
        self.native_recipe_sources(uuid, t.id, [pos.0, pos.1, pos.2], &mut asked);
        let mut sources: Vec<((i32, i32, i32), Vec<Option<ItemStack>>)> = Vec::new();
        for at in asked {
            let at = (at[0], at[1], at[2]);
            if at == pos || sources.len() >= MAX_RECIPE_SOURCES || sources.iter().any(|s| s.0 == at)
            {
                continue;
            }
            let Some(items) = self.linkable_container(at) else {
                continue;
            };
            sources.push((at, items));
        }
        sources
    }

    /// The slots of the block container at `at` that a mod may lend a menu
    /// (`native_recipe_sources`, `native_menu_links`): a chest-like block
    /// entity's (chests, barrels, shulker boxes, hoppers, dispensers,
    /// droppers) or a mod container's, while it is in the world (not
    /// ticking). None for anything else.
    fn linkable_container(&self, at: (i32, i32, i32)) -> Option<Vec<Option<ItemStack>>> {
        let state = self.world.block(at.0, at.1, at.2).0;
        match self.world.block_entities.get(&at)? {
            BlockEntity::Chest(items) => Some(items.clone()),
            BlockEntity::Mod(m) if !m.id().is_empty() => {
                let c = self.world.block_entities.mod_container(state)?;
                Some(m.items.iter().take(c.slots).cloned().collect())
            }
            _ => None,
        }
    }

    /// The guests' open mod menus with linked slots (`links`): the mods name
    /// the containers behind them again (`native_menu_links`), before the
    /// hub sends the tick's slot changes, so a tab the player picked or a
    /// chest placed or broken shows in the same tick.
    pub(super) fn lan_menu_links_tick(&mut self) {
        let Some(count) = self.lan.as_ref().map(|host| host.hub.guests.len()) else {
            return;
        };
        for gi in 0..count {
            let host = self.lan.as_ref().unwrap();
            let g = &host.hub.guests[gi];
            let Some((t, pos)) =
                g.menu.as_ref().filter(|_| host.hub.here(g)).and_then(|m| {
                    match (m.mod_type, m.slots) {
                        (Some(t), Slots::Block(pos)) if t.links.is_some() => Some((t, pos)),
                        _ => None,
                    }
                })
            else {
                continue;
            };
            let mut asked = Vec::new();
            self.native_menu_links(g.uuid, t.id, [pos.0, pos.1, pos.2], &mut asked);
            let mut links: Vec<(i32, i32, i32)> = Vec::new();
            for at in asked {
                let at = (at[0], at[1], at[2]);
                if at == pos || links.len() >= MAX_MENU_LINKS || links.contains(&at) {
                    continue;
                }
                if self.linkable_container(at).is_some() {
                    links.push(at);
                }
            }
            self.lan.as_mut().unwrap().hub.guests.update(gi, |g| {
                if let Some(m) = g.menu.as_mut() {
                    m.links = links;
                }
            });
        }
    }

    /// The result guest `gi`'s mod crafting menu shows, with its slot, while
    /// the block entity's grid (`items`) is the one it was made from.
    fn lan_mod_craft_shown(
        host: &super::lan::LanHost,
        gi: usize,
        items: &[Option<ItemStack>],
    ) -> Option<(usize, Option<ItemStack>)> {
        let menu = host.hub.guests[gi].menu.as_ref()?;
        let c = menu.mod_type?.crafting?;
        let craft = menu.craft.as_ref()?;
        (items.get(c.grid_slots()) == Some(&craft.grid[..]))
            .then(|| (c.result, craft.result.clone()))
    }

    /// After the menu engine ran on guest `gi`'s mod crafting menu at `pos`:
    /// the mods have their say on the result (`native_prepare_item_craft`,
    /// as on a crafting table's), which goes into `menu` and is what the guest
    /// is shown from now on. The result's slot when the mods changed it.
    fn lan_mod_craft_settle(
        &mut self,
        gi: usize,
        pos: (i32, i32, i32),
        menu: &mut Menu,
    ) -> Option<usize> {
        let c = menu.mod_crafting()?;
        let guest = &self.lan.as_ref()?.hub.guests[gi];
        let (uuid, name) = (guest.uuid, guest.name.clone());
        let mut result = menu.slot(c.result).cloned();
        let vanilla = result.clone();
        self.native_prepare_item_craft(uuid, &name, Some([pos.0, pos.1, pos.2]), &mut result);
        let grid = c.grid_slots().map(|k| menu.slot(k).cloned()).collect();
        let changed = result != vanilla;
        if changed {
            menu.set_slot(&self.menu_env(), c.result, result.clone());
        }
        self.lan.as_mut()?.hub.guests.update(gi, |guest| {
            if let Some(m) = guest.menu.as_mut() {
                m.craft = Some(ModCraft { grid, result });
            }
        });
        changed.then_some(c.result)
    }

    /// `CraftingMenu.slotsChanged` for the guests' mod crafting menus: the
    /// result each is shown follows its block entity's grid, which another
    /// player, a hopper or the mod may have changed, made again only when
    /// the grid changed.
    pub(super) fn lan_mod_crafting_tick(&mut self) {
        let Some(count) = self.lan.as_ref().map(|host| host.hub.guests.len()) else {
            return;
        };
        for gi in 0..count {
            let Some(host) = self.lan.as_ref() else {
                return;
            };
            let g = &host.hub.guests[gi];
            let Some((t, pos)) =
                g.menu.as_ref().filter(|_| host.hub.here(g)).and_then(|m| {
                    match (m.mod_type, m.slots) {
                        (Some(t), Slots::Block(pos)) if t.crafting.is_some() => Some((t, pos)),
                        _ => None,
                    }
                })
            else {
                continue;
            };
            let Some(BlockEntity::Mod(m)) = self.world.block_entities.get(&pos) else {
                continue;
            };
            let mut items = m.items.clone();
            items.resize(t.slots, None);
            if Self::lan_mod_craft_shown(host, gi, &items).is_some() {
                continue;
            }
            let mut menu = Menu::new(Kind::Mod(t));
            self.guest_menu_op(gi, &mut menu, |menu, env| {
                menu.load_container(env, &items);
            });
            self.lan_mod_craft_settle(gi, pos, &mut menu);
        }
    }

    /// `ServerPlayer.tick`'s `stillValid`: a guest's crafting table closes
    /// once it is gone or out of reach, giving its grid back.
    pub(super) fn lan_tables_tick(&mut self) {
        let Some(host) = self.lan.as_ref() else {
            return;
        };
        let invalid: Vec<(u32, i32)> = host
            .play
            .iter()
            .filter_map(|(c, p)| p.crafting.table.as_ref().map(|t| (*c, t.0, t.3)))
            .filter(|&(c, _, pos)| {
                host.hub
                    .guests
                    .iter()
                    .find(|g| g.conn == c)
                    .is_some_and(|g| host.hub.here(g) && !self.lan_table_valid(g, pos))
            })
            .map(|(c, window, _)| (c, window))
            .collect();
        for (conn, window) in invalid {
            self.lan_crafting_closed(conn, Some(window));
            let Some(host) = self.lan.as_mut() else {
                return;
            };
            host.hub.send_to(
                conn,
                &C::ContainerClose(play::ContainerClose { container: window }),
            );
            if let Some(gi) = host.hub.guests.iter().position(|g| g.conn == conn) {
                self.guest_carried_back(gi);
            }
        }
    }

    /// The whole crafting table menu for the client (`sendAllDataToRemote`).
    fn lan_send_table_content(&mut self, conn: u32) {
        let Some(host) = self.lan.as_mut() else {
            return;
        };
        let Some(gi) = host.hub.guests.iter().position(|g| g.conn == conn) else {
            return;
        };
        let Some((window, state, menu, _)) = host
            .play
            .get_mut(&conn)
            .and_then(|p| p.crafting.table.as_mut())
        else {
            return;
        };
        *state = (*state + 1) & 0x7FFF;
        let (window, state) = (*window, *state);
        let mut items: Vec<Option<ItemStack>> = (0..10).map(|s| menu.slot(s).cloned()).collect();
        let g = &host.hub.guests[gi];
        items.extend((9..36).chain(0..9).map(|i| g.inventory[i].clone()));
        let carried = g.carried.clone();
        let items = items.iter().map(|s| host.hub.stack(s)).collect();
        let carried = host.hub.stack(&carried);
        host.hub.send_to(
            conn,
            &C::ContainerSetContent(play::ContainerSetContent {
                container: window,
                state,
                items,
                carried,
            }),
        );
        host.hub.guests.update(gi, |g| g.inventory_told());
    }

    /// `AbstractContainerMenu.removed` of a crafting menu: the closed window
    /// (`window`; None closes the table whichever it is, and 0 the inventory
    /// menu) gives its grid back to the inventory, what doesn't fit is
    /// dropped. False when no such window is open.
    /// The open crafting table's own slots (result and grid) before the
    /// player's inventory, if the guest has one open.
    pub(super) fn lan_crafting_table_own_slots(&self, conn: u32) -> Option<usize> {
        let (_, _, menu, _) = self
            .lan
            .as_ref()?
            .play
            .get(&conn)?
            .crafting
            .table
            .as_ref()?;
        Some(menu.slot_count() - 36)
    }

    pub(super) fn lan_crafting_closed(&mut self, conn: u32, window: Option<i32>) -> bool {
        self.lan_crafting_removed(conn, window, MenuRemoval::Live)
    }

    /// Remove only input slots; disconnected players drop their inputs.
    pub(super) fn lan_crafting_removed(
        &mut self,
        conn: u32,
        window: Option<i32>,
        removal: MenuRemoval,
    ) -> bool {
        let Some(host) = self.lan.as_mut() else {
            return false;
        };
        let Some(gi) = host.hub.guests.iter().position(|g| g.conn == conn) else {
            return false;
        };
        let crafting = &mut host.play.entry(conn).or_default().crafting;
        let grid: Vec<ItemStack> = if window == Some(0) {
            crafting.inventory = None;
            host.hub.guests.update(gi, |g| {
                g.craft_result = None;
                g.craft_grid.iter_mut().filter_map(Option::take).collect()
            })
        } else {
            match crafting
                .table
                .take_if(|(w, ..)| window.is_none_or(|window| *w == window))
            {
                Some((_, _, menu, _)) => (1..10).filter_map(|s| menu.slot(s).cloned()).collect(),
                None => return false,
            }
        };
        if !grid.is_empty() {
            match removal {
                MenuRemoval::Live => self.lan_place_back(gi, grid),
                MenuRemoval::Disconnected => self.drop_guest_items(gi, grid),
            }
        }
        true
    }

    /// `Inventory.placeItemBackInInventory` of `stacks` for guest `gi`, what
    /// doesn't fit dropped (`clearContainer`).
    pub(super) fn lan_place_back(&mut self, gi: usize, stacks: Vec<ItemStack>) {
        let mut menu = Menu::new(Kind::Inventory);
        self.guest_menu_op(gi, &mut menu, |menu, env| place_back(menu, env, stacks));
    }

    /// A guest left: what their crafting grids and workstation held goes back into their
    /// inventory before it is saved (dropped where they stood if full).
    pub(super) fn lan_crafting_left(&mut self, g: &mut Guest) {
        // The guest's play state stays: their statistics are awarded and saved
        // after this (`HostEvent::Left`), which removes it.
        let Some(host) = self.lan.as_mut() else {
            return;
        };
        let play = host.play.get_mut(&g.conn);
        let mut grid: Vec<ItemStack> = g.craft_grid.iter_mut().filter_map(Option::take).collect();
        g.craft_result = None;
        if let Some(play) = play {
            if let Some((_, _, menu, _)) = play.crafting.table.take() {
                grid.extend((1..10).filter_map(|s| menu.slot(s).cloned()));
            }
            // A workstation's inputs too.
            if let Some(station) = play.station.take() {
                grid.extend(super::lan_stations::station_inputs(&station));
            }
        }
        if grid.is_empty() {
            return;
        }
        let mut menu = Menu::new(Kind::Inventory);
        load_player(&mut menu, g);
        place_back(&mut menu, &self.menu_env(), grid);
        let dropped = std::mem::take(&mut menu.dropped);
        store_player(&mut menu, g);
        for stack in dropped {
            self.spawn_item(stack, g.position, [0.0, 0.1, 0.0], 40);
        }
    }
}

#[cfg(test)]
mod machine_recipe_placement_tests {
    use super::*;
    use horizon_client::lan::{Joined, NetConfig, PlayerSender, guest::Guest, hub::HubConfig};
    use horizon_core::position::ChunkPos;
    use horizon_protocol::packets::{
        configuration::ClientInformation,
        play::{Serverbound, UseItemOn},
        recipes::PlaceRecipe,
    };
    use std::sync::{Arc, atomic::AtomicI32, mpsc};

    #[test]
    #[ignore = "needs prepared resources in HORIZON_TEST_RESOURCES"]
    fn h234_registered_place_recipe_reaches_actual_furnace_and_preserves_controls() {
        crate::game::native_entity_refs::tests::with_game(|game| {
            game.build_registries();
            game.set_allow_commands(true);
            game.world.chunks.insert(
                (0, 0),
                std::sync::Arc::new(horizon_client::chunk::Chunk::empty(0, 0)),
            );
            game.block_ticks
                .add_empty_chunk(ChunkPos::new(0, 0))
                .unwrap();
            assert!(game.run_command("fill 0 199 0 15 199 15 stone"));
            assert!(game.world.loaded(8, 8));
            game.lan_host(
                crate::game::lan::LanSettings {
                    port: 0,
                    guest_commands: true,
                    force_game_mode: false,
                },
                NetConfig {
                    announce: false,
                    ..NetConfig::loopback(0, "machine-place-test".into(), 2)
                },
                HubConfig {
                    default_game_mode: 0,
                    guest_commands: true,
                    force_game_mode: false,
                    hardcore: false,
                    view_distance: 2,
                    simulation_distance: 2,
                    dimension: "minecraft:overworld".into(),
                    allow_flight: false,
                    seed: 0,
                    max_players: 2,
                    integrated: false,
                    levels: Default::default(),
                },
            )
            .unwrap();
            let (tx, _rx) = mpsc::channel();
            let mut guest = Guest::new(
                Joined {
                    conn: 2,
                    uuid: 234,
                    name: "RecipeGuest".into(),
                    properties: Vec::new(),
                    info: ClientInformation::new(2),
                    brand: "test".into(),
                    sender: PlayerSender::new(tx, Arc::default()),
                    latency: Arc::new(AtomicI32::new(0)),
                    address: "127.0.0.1:25565".parse().unwrap(),
                    expected: false,
                },
                2,
                [8.5, 200.0, 8.5],
                2,
            );
            guest.dimension = "minecraft:overworld".into();
            guest.placed = true;
            guest.loaded = true;
            guest.selected = 1;
            guest.permission = 2;
            game.lan.as_mut().unwrap().hub.guests.push(guest);
            let clock = game.world.game_time;
            let planks = game
                .stations()
                .recipe_index
                .first_display("minecraft:oak_planks")
                .unwrap();
            let charcoal = game
                .stations()
                .recipe_index
                .first_display("minecraft:charcoal")
                .unwrap();
            let command = |game: &mut Game<'_>, text: &str| {
                assert!(game.as_guest(2, |g| g.run_command(text)).unwrap(), "{text}");
            };
            let place = |game: &mut Game<'_>, container, recipe| {
                game.lan_guest_packet(
                    2,
                    Serverbound::PlaceRecipe(PlaceRecipe {
                        container,
                        recipe,
                        use_max: false,
                    }),
                );
            };
            let open = |game: &mut Game<'_>, pos| {
                game.lan_guest_packet(
                    2,
                    Serverbound::UseItemOn(UseItemOn {
                        hand: 0,
                        pos,
                        face: 1,
                        cursor: [0.5, 1.0, 0.5],
                        inside: false,
                        world_border: false,
                        sequence: 234,
                    }),
                );
                assert!(
                    game.lan
                        .as_ref()
                        .unwrap()
                        .hub
                        .guest(2)
                        .unwrap()
                        .ack_up_to
                        .get()
                        >= 234
                );
                game.lan
                    .as_ref()
                    .unwrap()
                    .play
                    .get(&2)
                    .and_then(|p| p.crafting.table.as_ref())
                    .map(|(window, ..)| *window)
                    .or_else(|| {
                        game.lan
                            .as_ref()
                            .unwrap()
                            .hub
                            .guest(2)
                            .unwrap()
                            .menu
                            .as_ref()
                            .map(|m| m.window)
                    })
                    .expect("actual table or machine window opened")
            };
            command(game, "recipe give @s minecraft:oak_planks");
            command(game, "recipe give @s minecraft:charcoal");
            assert!(
                game.lan
                    .as_ref()
                    .unwrap()
                    .hub
                    .guest(2)
                    .unwrap()
                    .recipe_book
                    .knows("minecraft:charcoal")
            );
            command(game, "item replace entity @s hotbar.0 with oak_log 3");
            place(game, 0, planks);
            assert_eq!(
                game.lan.as_ref().unwrap().hub.guest(2).unwrap().craft_grid[0],
                Some(ItemStack::new("minecraft:oak_log", 1))
            );
            assert_eq!(
                game.lan
                    .as_ref()
                    .unwrap()
                    .hub
                    .guest(2)
                    .unwrap()
                    .craft_result,
                Some(ItemStack::new("minecraft:oak_planks", 4))
            );
            assert_eq!(
                game.lan.as_ref().unwrap().hub.guest(2).unwrap().inventory[0]
                    .as_ref()
                    .unwrap()
                    .count,
                2
            );
            game.lan_crafting_closed(2, Some(0));
            assert!(game.run_command("setblock 10 200 8 crafting_table"));
            let window = open(game, [10, 200, 8]);
            place(game, window, planks);
            let (_, _, table, _) = game.lan.as_ref().unwrap().play[&2]
                .crafting
                .table
                .as_ref()
                .unwrap();
            assert_eq!(
                table.slot(0),
                Some(&ItemStack::new("minecraft:oak_planks", 4))
            );
            game.guest_close_all(2);
            let mut failures = Vec::new();
            for (label, count, known) in [
                ("place", 3, true),
                ("ghost", 0, true),
                ("forgotten", 3, false),
            ] {
                game.as_guest(2, |g| {
                    g.run_command("clear @s");
                })
                .unwrap();
                if count > 0 {
                    command(game, "item replace entity @s hotbar.0 with oak_log 3");
                }
                command(
                    game,
                    "item replace entity @s hotbar.8 with stick[minecraft:custom_data={h234:1}] 7",
                );
                assert!(game.run_command("setblock 10 200 8 air"));
                assert!(game.run_command("setblock 10 200 8 furnace"));
                assert!(game.run_command("item replace block 10 200 8 container.1 with coal[minecraft:custom_data={h234:2}] 2"));
                let window = open(game, [10, 200, 8]);
                if !known {
                    command(game, "recipe take @s minecraft:charcoal");
                }
                assert_eq!(
                    game.lan
                        .as_ref()
                        .unwrap()
                        .hub
                        .guest(2)
                        .unwrap()
                        .recipe_book
                        .knows("minecraft:charcoal"),
                    known
                );
                let before = game
                    .lan
                    .as_ref()
                    .unwrap()
                    .hub
                    .guest(2)
                    .unwrap()
                    .inventory
                    .clone();
                let pos = (10, 200, 8);
                let Some(BlockEntity::Furnace(f)) = game.world.block_entities.get(&pos) else {
                    panic!("actual furnace missing")
                };
                assert!(f.items[0].is_none() && f.items[2].is_none());
                let fuel = f.items[1].clone();
                assert_eq!(fuel.as_ref().unwrap().count, 2);
                place(game, window, charcoal);
                let Some(BlockEntity::Furnace(f)) = game.world.block_entities.get(&pos) else {
                    panic!("furnace removed")
                };
                assert_eq!(f.items[1], fuel);
                assert!(f.items[2].is_none());
                let mut expected = before.clone();
                let input = if label == "place" {
                    expected[0].as_mut().unwrap().count = 2;
                    Some(ItemStack::new("minecraft:oak_log", 1))
                } else {
                    None
                };
                if f.items[0] != input
                    || game.lan.as_ref().unwrap().hub.guest(2).unwrap().inventory != expected
                {
                    failures.push((
                        label,
                        f.items.clone(),
                        game.lan
                            .as_ref()
                            .unwrap()
                            .hub
                            .guest(2)
                            .unwrap()
                            .inventory
                            .clone(),
                    ));
                }
                assert_eq!(game.lan.as_ref().unwrap().hub.guest(2).unwrap().uuid, 234);
                assert_eq!(
                    game.lan.as_ref().unwrap().hub.guest(2).unwrap().health,
                    20.0
                );
                assert_eq!(
                    game.lan.as_ref().unwrap().hub.guest(2).unwrap().position,
                    [8.5, 200.0, 8.5]
                );
                assert_eq!(game.world.game_time, clock);
                game.guest_close_all(2);
            }
            assert!(
                failures.is_empty(),
                "actual registered PlaceRecipe furnace failures: {failures:?}"
            );
        });
    }
}

#[cfg(test)]
mod creative_grid_tests {
    use super::*;
    use horizon_client::lan::{Joined, NetConfig, PlayerSender, guest::Guest, hub::HubConfig};
    use horizon_core::position::ChunkPos;
    use horizon_protocol::packets::{
        configuration::ClientInformation,
        play::{Serverbound, SetCreativeModeSlot},
    };
    use std::sync::{Arc, atomic::AtomicI32, mpsc};

    /// `handleSetCreativeModeSlot` sets a grid slot through its container, whose
    /// `InventoryMenu.slotsChanged` makes the result again: the creative screen's 2x2 grid
    /// (Bedrock Inventory) crafts on single player's own server too.
    #[test]
    #[ignore = "needs prepared resources in HORIZON_TEST_RESOURCES"]
    fn a_creative_grid_slot_makes_the_result_again() {
        crate::game::native_entity_refs::tests::with_game(|game| {
            game.build_registries();
            game.world.chunks.insert(
                (0, 0),
                std::sync::Arc::new(horizon_client::chunk::Chunk::empty(0, 0)),
            );
            game.block_ticks
                .add_empty_chunk(ChunkPos::new(0, 0))
                .unwrap();
            game.lan_host(
                crate::game::lan::LanSettings {
                    port: 0,
                    guest_commands: true,
                    force_game_mode: false,
                },
                NetConfig {
                    announce: false,
                    ..NetConfig::loopback(0, "creative-grid-test".into(), 2)
                },
                HubConfig {
                    default_game_mode: 0,
                    guest_commands: true,
                    force_game_mode: false,
                    hardcore: false,
                    view_distance: 2,
                    simulation_distance: 2,
                    dimension: "minecraft:overworld".into(),
                    allow_flight: false,
                    seed: 0,
                    max_players: 2,
                    integrated: false,
                    levels: Default::default(),
                },
            )
            .unwrap();
            let (tx, _rx) = mpsc::channel();
            let mut guest = Guest::new(
                Joined {
                    conn: 2,
                    uuid: 234,
                    name: "CreativeGuest".into(),
                    properties: Vec::new(),
                    info: ClientInformation::new(2),
                    brand: "test".into(),
                    sender: PlayerSender::new(tx, Arc::default()),
                    latency: Arc::new(AtomicI32::new(0)),
                    address: "127.0.0.1:25565".parse().unwrap(),
                    expected: false,
                },
                2,
                [8.5, 200.0, 8.5],
                2,
            );
            guest.dimension = "minecraft:overworld".into();
            guest.placed = true;
            guest.loaded = true;
            guest.game_mode = horizon_client::lan::guest::CREATIVE;
            game.lan.as_mut().unwrap().hub.guests.push(guest);
            // The creative screen's grid slot 1 set, and the result the server keeps.
            let set = |game: &mut Game<'_>, item: Option<ItemStack>| {
                let item = game.lan.as_mut().unwrap().hub.stack(&item);
                game.lan_guest_packet(
                    2,
                    Serverbound::SetCreativeModeSlot(SetCreativeModeSlot { slot: 1, item }),
                );
                game.lan
                    .as_ref()
                    .unwrap()
                    .hub
                    .guest(2)
                    .unwrap()
                    .craft_result
                    .clone()
            };
            assert_eq!(
                set(game, Some(ItemStack::new("minecraft:oak_log", 1))),
                Some(ItemStack::new("minecraft:oak_planks", 4))
            );
            assert_eq!(set(game, None), None);
        });
    }
}
