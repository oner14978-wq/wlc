//! The options screens bound to the game: drawing, input, applying settings
//! (video, sound, chat, font, language) and the F11 fullscreen toggle.
use super::{Game, ResizeState, Screen};
use horizon_client::{
    Result,
    graphics::Graphics,
    hdr_calibration::WindowState,
    hud::HudBatch,
    lang,
    options_ui::{Event, Page, SkinAction},
    window::{FrameContext, InactivityFpsLimit, framerate_limit},
};
use serde_json::{Value, json};
use winit::{event::MouseButton, keyboard::KeyCode, window::Fullscreen};

/// `CommonLinks.ACCESSIBILITY_HELP`, the Accessibility page's footer link.
pub(super) const ACCESSIBILITY_HELP_LINK: &str = "https://aka.ms/MinecraftJavaAccessibility";

pub(super) const CONTROL_HELP: &[&str] = &[
    "options-get [KEY...]           options.txt values by key, with their type, range or choices",
    "options-set KEY VALUE          set an option (enums by name, keys as key.keyboard.w, lists as JSON), apply and save it",
    "graphics-get [KEY...]          Horizon's graphics settings (graphics.txt) by key",
    "graphics-set KEY VALUE         set a Horizon graphics setting (resolutionScale 25..200, presentMode, workers...), apply and save it",
];

/// The catalog's shelf for a page's Catalog button.
#[cfg(target_os = "android")]
fn catalog_shelf(shelf: horizon_client::options_ui::CatalogShelf) -> starling_catalog::Shelf {
    use horizon_client::options_ui::CatalogShelf;
    match shelf {
        CatalogShelf::Mods => starling_catalog::Shelf::Mods,
        CatalogShelf::ResourcePacks => starling_catalog::Shelf::ResourcePacks,
        CatalogShelf::ShaderPacks => starling_catalog::Shelf::ShaderPacks,
    }
}

impl Game<'_> {
    /// One of the game's folders (packs, shader packs, mods) in the file manager. On a phone the
    /// Files app shows it through Starling's own provider, wherever the game keeps it. A folder it
    /// can't show from the app's private files gets the offer of the Starling folder instead.
    fn open_game_folder(&mut self, dir: &std::path::Path) {
        let _ = std::fs::create_dir_all(dir);
        #[cfg(target_os = "android")]
        if horizon_client::platform::open_folder(dir) != Some(true)
            && horizon_client::logging::game_home() == horizon_client::logging::private_home()
        {
            self.ask_files_offer();
        }
        #[cfg(not(target_os = "android"))]
        super::packs::open_folder(dir);
    }

    pub(super) fn save_title_options(&mut self) {
        if let Some(title) = &self.title
            && (title.last_server != self.settings.file.string("lastServer")
                || title.skip_multiplayer_warning
                    != self.settings.file.bool("skipMultiplayerWarning"))
        {
            self.settings.file.set(
                "lastServer",
                horizon_client::options_file::V::Str(title.last_server.clone()),
            );
            self.settings.file.set(
                "skipMultiplayerWarning",
                horizon_client::options_file::V::Bool(title.skip_multiplayer_warning),
            );
            self.settings.save(&Self::options_path());
        }
    }
    /// `options-get`, `options-set`, `graphics-get` and `graphics-set`; None for other commands.
    pub(super) fn options_control(&mut self, words: &[&str], line: &str) -> Result<Option<Value>> {
        match words[0] {
            "options-get" => {
                let file = self.settings.to_file();
                let wanted: Vec<&str> = if words.len() > 1 {
                    words[1..].to_vec()
                } else {
                    horizon_client::options_file::keys()
                };
                let mut options = serde_json::Map::new();
                for key in wanted {
                    let described = file.describe(key).ok_or_else(|| {
                        format!("unknown option {key}; options-get lists them all")
                    })?;
                    options.insert(key.to_owned(), described);
                }
                Ok(Some(json!({ "options": options })))
            }
            "options-set" => {
                let key = words.get(1).ok_or("options-set KEY VALUE")?;
                // The value runs to the end of the line (lists, server names).
                let value = line
                    .trim_start()
                    .strip_prefix("options-set")
                    .and_then(|rest| rest.trim_start().strip_prefix(key))
                    .map(str::trim)
                    .filter(|v| !v.is_empty())
                    .ok_or("options-set KEY VALUE: missing the value")?;
                let narrator = self.settings.narrator();
                let reduced = self.settings.reduced_debug_info;
                self.settings = self.settings.with_option(key, value)?;
                if self.settings.reduced_debug_info != reduced {
                    self.debug_entries.invalidate();
                }
                // As the options screen applies a change (OptionInstance.set
                // runs the narrator's onValueUpdate for a new value only).
                let mut events = vec![Event::Changed];
                if self.settings.narrator() != narrator {
                    events.push(Event::Narrator);
                }
                self.handle_option_events(events)?;
                match *key {
                    "lang" => self.load_language(&self.settings.language.clone()),
                    "resourcePacks" | "incompatibleResourcePacks" => self.reload_packs(),
                    _ => {}
                }
                // Labels change (a language, a value): `ui` reads the redrawn screen.
                self.ui_wait.clicked();
                let now = self.settings.to_file().describe(key);
                Ok(Some(json!({ "ok": true, "key": key, "option": now })))
            }
            "graphics-get" => {
                let text = self.settings.horizon.serialize();
                let all: Vec<(&str, &str)> =
                    text.lines().filter_map(|l| l.split_once(':')).collect();
                if let Some(key) = words[1..]
                    .iter()
                    .find(|k| !all.iter().any(|(a, _)| a == *k))
                {
                    return Err(
                        format!("unknown graphics key {key}; graphics-get lists them all").into(),
                    );
                }
                let graphics: serde_json::Map<String, Value> = all
                    .into_iter()
                    .filter(|(k, _)| words.len() == 1 || words[1..].contains(k))
                    .map(|(k, v)| (k.to_owned(), v.into()))
                    .collect();
                Ok(Some(json!({ "graphics": graphics })))
            }
            "graphics-set" => {
                let (Some(key), Some(_)) = (words.get(1), words.get(2)) else {
                    return Err("graphics-set KEY VALUE".into());
                };
                let value = words[2..].join(" ");
                // graphics.txt's own reading, with the new line last.
                let text = self.settings.horizon.serialize();
                let line = |text: &str| {
                    text.lines()
                        .find(|l| l.split_once(':').is_some_and(|(k, _)| k == *key))
                        .map(str::to_owned)
                };
                let before = line(&text).ok_or_else(|| {
                    format!("unknown graphics key {key}; graphics-get lists them all")
                })?;
                let graphics = Graphics::parse(&format!(
                    "{text}{key}:{value}
"
                ));
                let after = line(&graphics.serialize()).unwrap_or_default();
                if after == before && after != format!("{key}:{value}") {
                    return Err(format!("{key} does not take {value}; it stays {before}").into());
                }
                self.settings.horizon = graphics;
                self.handle_option_events(vec![Event::Changed])?;
                let now = after.split_once(':').map_or("", |(_, v)| v).to_owned();
                // The worker pool and the graphics API are made once, at start.
                let restart = matches!(*key, "workers" | "graphicsApi");
                Ok(Some(
                    json!({ "ok": true, "key": key, "value": now, "restart": restart }),
                ))
            }
            _ => Ok(None),
        }
    }
    /// This player's `options.txt`: in the game folder, or in `--player-dir` when several
    /// players share one (`logging::set_player_dir`).
    pub(super) fn options_path() -> std::path::PathBuf {
        // Splitscreen's second player has its own options (`split::options_path`).
        if let Some(path) = super::split::options_path() {
            return path;
        }
        horizon_client::logging::player_dir().join("options.txt")
    }
    /// The game folder (the working directory): what its players share, saves, packs, mods.
    pub(super) fn game_dir() -> std::path::PathBuf {
        std::env::current_dir().unwrap_or_default()
    }
    /// `shaderpacks/` in the game folder.
    pub(super) fn shader_packs_dir() -> std::path::PathBuf {
        Self::game_dir().join(horizon_client::shader_pack_list::DIR)
    }
    pub(super) fn gui_size(&self) -> (f32, f32) {
        let size = self
            .renderer
            .as_ref()
            .map_or([1280, 720], |r| [r.config.width, r.config.height]);
        let b = HudBatch::new(size, self.settings.gui_scale_inputs());
        (b.width, b.height)
    }
    /// Open the options screens (OptionsScreen) from the title or pause menu.
    pub(super) fn open_options(&mut self, from_title: bool) {
        self.open_options_at(from_title, Page::Main);
    }
    pub(super) fn open_options_at(&mut self, from_title: bool, page: Page) {
        #[cfg(target_os = "android")]
        self.mobile_options_open();
        // Gameplay keys must not stay held behind the options screen, where
        // bindings can also change before the physical key is released.
        self.keys.clear();
        self.set_screen(Screen::Options);
        self.options_from_title = from_title;
        let minecart_improvements = self.minecart_improvements();
        let ui = &mut self.ui.options;
        // The game puts the skin on (game/own_skin.rs).
        ui.skin_page = true;
        ui.profile_name = horizon_client::accounts::player_name();
        ui.profile_key = horizon_client::accounts::player_key();
        ui.skin_cloud = horizon_client::accounts::skin_cloud();
        ui.offer_catalog();
        ui.open_at(!from_title && self.title.is_none(), page);
        ui.minecart_improvements = minecart_improvements;
        ui.languages = lang::available(&[&self.pack.source]);
        self.refresh_pack_lists();
    }
    /// While the resource pack screen is open, `resourcepacks/` is looked at once a second
    /// and the list found again when its packs changed (`PackSelectionScreen.tick`'s
    /// watcher).
    fn watch_pack_folder(&mut self) {
        if !self.ui.options.resource_packs_open() {
            self.pack_folder = None;
            return;
        }
        let now = std::time::Instant::now();
        if self
            .pack_folder
            .as_ref()
            .is_some_and(|(at, _)| now.duration_since(*at).as_secs_f32() < 1.0)
        {
            return;
        }
        let signature: Vec<(String, u64, Option<std::time::SystemTime>)> =
            std::fs::read_dir(super::packs::packs_dir())
                .into_iter()
                .flatten()
                .flatten()
                .map(|e| {
                    let meta = e.metadata().ok();
                    (
                        e.file_name().to_string_lossy().into_owned(),
                        meta.as_ref().map_or(0, |m| m.len()),
                        meta.and_then(|m| m.modified().ok()),
                    )
                })
                .collect();
        let changed = self
            .pack_folder
            .as_ref()
            .is_some_and(|(_, seen)| *seen != signature);
        self.pack_folder = Some((now, signature));
        if changed {
            let infos = self.resource_pack_infos();
            self.ui.options.update_pack_infos(infos);
            self.ui.options.pack_configs = super::packs::pack_configs(&self.vanilla_root());
        }
    }
    pub(super) fn draw_options(&mut self, batch: &mut HudBatch) {
        self.watch_pack_folder();
        self.poll_diagnostics();
        let context = self.controller_settings_context();
        self.show_skin_cloud();
        let mut ui = std::mem::take(&mut self.ui.options);
        if ui.controller_open() {
            ui.set_controller_context(context);
        }
        let cursor = self.options_pointer(&mut ui);
        let output = self
            .renderer
            .as_ref()
            .map_or(Default::default(), |r| r.output());
        ui.draw(&self.settings, output, batch, &self.gui.atlas, cursor);
        self.ui.options = ui;
        self.show_calibration((batch.width, batch.height));
    }
    /// Whose controller settings these are and what this game sees (`controller_ui`): the
    /// player's badge in splitscreen with its name, and its own controller.
    fn controller_settings_context(&self) -> horizon_client::controller_ui::Context {
        let name = self.options.player_name();
        let player = match &self.split_hud.badge {
            Some(badge) if *badge != name => format!("{badge} · {name}"),
            _ => name,
        };
        horizon_client::controller_ui::Context {
            player,
            device: self.pad.device_or_virtual(),
            detected: detected_controller_style(self.pad.device.as_ref(), self.pad.style),
            glyphs: self.ui.options.pad_glyphs,
        }
    }
    /// HDR calibration's test picture to the renderer, full screen while it runs: the
    /// window goes fullscreen for it and back after, as it was (maximized, say).
    pub(super) fn show_calibration(&mut self, size: (f32, f32)) {
        let picture = (self.screen == Screen::Options)
            .then(|| self.ui.options.calibration_picture(&self.gui.atlas, size))
            .flatten();
        if let Some(r) = self.renderer.as_mut() {
            r.set_hdr_calibration(picture.map(|(step, nits, band)| {
                horizon_client::gfx::HdrCalibration {
                    step: step.number(),
                    nits,
                    band,
                }
            }));
        }
        let Some(window) = &self.window else {
            return;
        };
        match (picture.is_some(), self.ui.options.calibration_window) {
            (true, None) => {
                // Before entering fullscreen, which un-maximizes a window on Windows.
                let was = WindowState::of(window.fullscreen().is_some(), window.is_maximized());
                if was != WindowState::Fullscreen {
                    let borderless = horizon_client::window::borderless_fullscreen(window);
                    horizon_client::window::enter_fullscreen(window, borderless);
                }
                self.ui.options.calibration_window = Some(was);
            }
            (false, Some(was)) => {
                let (leave_fullscreen, maximize) = was.leaving();
                if leave_fullscreen {
                    window.set_fullscreen(None);
                }
                if maximize {
                    window.set_maximized(true);
                }
                self.ui.options.calibration_window = None;
            }
            _ => {}
        }
    }
    pub(super) fn options_mouse(&mut self, pressed: bool, right: bool) -> Result<()> {
        if !pressed {
            if right {
                return Ok(());
            }
            let events = self.ui.options.release();
            self.dragging = false;
            return self.handle_option_events(events);
        }
        if !right {
            self.dragging = true;
        }
        let size = self.gui_size();
        let framebuffer = self.renderer.as_ref().map_or([1280, 720], |r| {
            [r.config.width as i32, r.config.height as i32]
        });
        let mut ui = std::mem::take(&mut self.ui.options);
        ui.shift = self.modifiers.shift_key();
        let events = ui.click(
            &mut self.settings,
            &self.gui.atlas,
            self.cursor.0,
            self.cursor.1,
            size,
            framebuffer,
            false,
            right,
        );
        self.ui.options = ui;
        self.handle_option_events(events)
    }
    pub(super) fn options_drag(&mut self) -> Result<()> {
        let size = self.gui_size();
        let framebuffer = self.renderer.as_ref().map_or([1280, 720], |r| {
            [r.config.width as i32, r.config.height as i32]
        });
        let mut ui = std::mem::take(&mut self.ui.options);
        let events = ui.click(
            &mut self.settings,
            &self.gui.atlas,
            self.cursor.0,
            self.cursor.1,
            size,
            framebuffer,
            true,
            false,
        );
        self.ui.options = ui;
        self.handle_option_events(events)
    }
    pub(super) fn options_key(&mut self, key: KeyCode, text: Option<&str>) -> Result<()> {
        let size = self.gui_size();
        let shift = self.has_shift_down();
        let framebuffer = self.renderer.as_ref().map_or([1280, 720], |r| {
            [r.config.width as i32, r.config.height as i32]
        });
        self.ui.options.size = size;
        self.ui.options.framebuffer = framebuffer;
        let mut ui = std::mem::take(&mut self.ui.options);
        ui.modifiers = self.modifiers().bits;
        let events = ui.key_modifiers(&mut self.settings, &self.gui.atlas, key, text, shift);
        self.ui.options = ui;
        self.handle_option_events(events)
    }
    /// Ctrl+A/C/V/X in the options' search boxes; false when none has focus.
    pub(super) fn options_shortcut(
        &mut self,
        shortcut: horizon_client::clipboard::EditShortcut,
    ) -> bool {
        self.ui
            .options
            .shortcut(&self.gui.atlas, shortcut, &mut self.clipboard)
    }
    /// The wheel on the options. A finger's scroll (`finger`) only scrolls: a list moved by a
    /// finger that landed on a cycle button must not cycle it at each step, as a mouse wheel over it
    /// does (`CycleButton.mouseScrolled`).
    pub(super) fn options_scroll(&mut self, amount: f32, finger: bool) -> Result<()> {
        if self.pad_stick_scroll() {
            let size = self.gui_size();
            self.ui
                .options
                .scroll_at(&self.settings, size, self.cursor, amount);
            return Ok(());
        }
        let framebuffer = self.renderer.as_ref().map_or([1280, 720], |r| {
            [r.config.width as i32, r.config.height as i32]
        });
        if self.ui.options.video_open() && self.has_control_down() {
            // VideoSettingsScreen.mouseScrolled: Ctrl with the wheel steps the GUI scale.
            let mut ui = std::mem::take(&mut self.ui.options);
            let events = ui.video_wheel_gui_scale(&mut self.settings, framebuffer, amount);
            self.ui.options = ui;
            return self.handle_option_events(events);
        }
        let size = self.gui_size();
        if finger {
            self.ui
                .options
                .scroll_at(&self.settings, size, self.cursor, amount);
            return Ok(());
        }
        let events =
            self.ui
                .options
                .wheel(&mut self.settings, size, self.cursor, framebuffer, amount);
        self.handle_option_events(events)
    }
    /// Mouse buttons pressed while a key is being bound.
    pub(super) fn options_waiting_for_key(&self) -> bool {
        self.ui.options.selected_key.is_some()
    }
    pub(super) fn options_bind_mouse(&mut self, button: MouseButton) -> Result<()> {
        self.ui.options.modifiers = self.modifiers().bits;
        let events = self.ui.options.bind_mouse(&mut self.settings, button);
        self.handle_option_events(events)
    }
    pub(super) fn handle_option_events(&mut self, events: Vec<Event>) -> Result<()> {
        for e in events {
            match e {
                Event::DiagnosticsExport => self.export_diagnostics(),
                Event::DiagnosticsOpen => self.open_diagnostics(),
                Event::DiagnosticsRecord => self.toggle_diagnostic_recording(),
                Event::DiagnosticsGpu => self.toggle_diagnostic_gpu(),
                Event::ButtonClick => self.audio.play_button_click(),
                Event::DebugEntriesChanged => self.debug_entries.invalidate(),
                Event::Changed => {
                    #[cfg(target_os = "android")]
                    self.mobile_options_apply();
                    self.settings.save(&Self::options_path());
                    self.settings.keys.sync_action_bindings();
                    self.apply_settings();
                    self.switch_mods();
                    self.sync_native_switches();
                    self.sync_pregen_option();
                    self.sync_agent_control();
                    self.ui.options.agent_status = self.agent_status_lines();
                }
                Event::SliderDrag => {
                    #[cfg(target_os = "android")]
                    self.mobile_options_apply();
                    self.apply_settings();
                }
                // Options.createSoundSliderOptionInstance: the preview plays
                // only without a level (on the title screen's options).
                Event::Volume(source, volume) if self.title.is_some() => {
                    self.audio.preview(source, volume);
                }
                Event::Volume(..) => {}
                Event::CopyAgentDetails => {
                    use horizon_client::clipboard::Clipboard;
                    let text = self.agent_details();
                    self.clipboard.set(&text);
                }
                // The AI Agent page's repro buttons (game/runtime/repro.rs).
                Event::ToggleRecording => self.toggle_recording_key(),
                Event::ExportRepro => self.export_repro_key(),
                // The Music page: the situations' tracks, and playing one now.
                Event::ListMusicTracks => self.ui.options.music_groups = self.music_groups(),
                Event::PlayMusicTrack(event, track) => self.play_music_track(&event, &track),
                Event::Close if self.ui.options.resource_error.is_some() => {}
                Event::Close => {
                    self.settings.save(&Self::options_path());
                    let to_game = self.options_from_title;
                    let back = if let Some(screen) = self.panel.recipes_settings_return.take() {
                        screen
                    } else if std::mem::take(&mut self.options_to_world_options) {
                        Screen::WorldOptions
                    } else if self.options_from_title {
                        Screen::Playing
                    } else {
                        Screen::Paused
                    };
                    self.set_screen(back);
                    if to_game {
                        self.capture(true);
                    }
                    self.dragging = false;
                    // Closed from calibration (horizon-ctl, a lost window): out of it.
                    self.show_calibration((0.0, 0.0));
                }
                Event::Language(code) => {
                    self.load_language(&code);
                }
                Event::Packs(_) => {
                    self.settings.save(&Self::options_path());
                    self.reload_packs();
                }
                Event::PackOptions { entries, chosen } => {
                    super::packs::save_pack_options(&entries, chosen);
                    self.ui.options.pack_configs = super::packs::pack_configs(&self.vanilla_root());
                    self.reload_packs();
                }
                Event::OpenPackFolder => self.open_game_folder(&super::packs::packs_dir()),
                Event::OpenModFolder => {
                    self.open_game_folder(&Self::game_dir().join(horizon_client::mod_list::DIR))
                }
                // Horizon's own Add button: the screen picked a hit, the game
                // owns the folder it lands in.
                Event::DownloadPack(i) => {
                    let dir = super::packs::packs_dir();
                    if let Some(screen) = &mut self.ui.options.pack_screen
                        && let Some(browser) = &mut screen.browser
                    {
                        browser.download(i, &dir, horizon_core::VANILLA_VERSION);
                    }
                }
                #[cfg(target_os = "android")]
                Event::OpenCatalog(shelf) => self.open_catalog_on(catalog_shelf(shelf)),
                #[cfg(not(target_os = "android"))]
                Event::OpenCatalog(_) => {}
                Event::DataPacks(ids) => {
                    let resources = self.vanilla_root();
                    if let Some(title) = &mut self.title {
                        title.offer_data_packs(&resources, ids);
                    }
                }
                Event::OpenDataPackFolder(dir) => self.open_game_folder(&dir),
                // The editor works over the world, or over the title before one: the menus
                // close for it.
                Event::TouchLayout => {
                    self.settings.save(&Self::options_path());
                    self.screen = Screen::Playing;
                    self.dragging = false;
                    self.open_touch_editor();
                }
                // The Mods screen's links go through ConfirmLinkScreen, back to the options.
                Event::OpenLink(url) => self.confirm_untrusted_link(&url, Screen::Options),
                Event::CopyText(text) => {
                    use horizon_client::clipboard::Clipboard;
                    self.clipboard.set(&text);
                }
                Event::BrowseMods => {
                    let ui = &mut self.ui.options.mod_browser;
                    self.mod_jobs.browse(ui, Self::game_dir());
                }
                Event::InstallMod(id) => {
                    if self.player.is_none() {
                        let ui = &mut self.ui.options.mod_browser;
                        self.mod_jobs.install(ui, Self::game_dir(), id);
                    }
                }
                // The website, through ConfirmLinkScreen as other links.
                Event::OpenModPage(url) => self.confirm_trusted_link(&url, Screen::Options),
                Event::ListShaderPacks => {
                    let (key, _) = horizon_client::shader_pack_list::resolve(
                        &Self::shader_packs_dir(),
                        &self.settings.horizon.shader_pack,
                    );
                    if key != self.settings.horizon.shader_pack {
                        self.settings.horizon.shader_pack = key;
                        self.settings.save(&Self::options_path());
                    }
                    self.settings.shader_packs =
                        horizon_client::shader_pack_list::scan(&Self::shader_packs_dir());
                }
                Event::ListMods => self.list_copied_native_mods(),
                Event::ModToggled(i) => self.mod_toggled(i),
                Event::NativeGame(act) => self.native_game_button(act),
                // Saved; the next frame's `shader_pack_inputs` loads the pick.
                Event::ShaderPack => self.settings.save(&Self::options_path()),
                Event::OpenCustomButtons => self.open_custom_buttons(),
                Event::CustomButtons => self.save_custom_buttons(),
                Event::CustomImage(id, pixels) => {
                    if let Err(e) = horizon_client::own_buttons::save(id, &pixels) {
                        log::warn!("Horizon: the button image was not saved: {e}");
                    }
                    self.save_custom_buttons();
                }
                Event::ImportButtonImage(id) => self.pick_button_image(id),
                Event::OpenShaderOptions => self.open_shader_options(),
                Event::ShaderOptions => self.save_shader_options(),
                Event::NativePackOptions(i) => {
                    if let Some(pack) = self.settings.shader_packs.get(i) {
                        pack.save_values(&Self::shader_packs_dir());
                    }
                }
                Event::OpenShaderPackFolder => self.open_game_folder(&Self::shader_packs_dir()),
                Event::NativeSettings(i) => self.native_settings_refresh(i),
                Event::NativeSetting(i, j) => self.native_setting_event(i, j),
                Event::Credits => self.open_win_screen(false, super::win::Finish::Options),
                Event::HudEditor => self.open_hud_editor(true),
                // AccessibilityOptionsScreen's link button: ConfirmLinkScreen
                // back to the options screen.
                Event::AccessibilityHelp => {
                    self.confirm_trusted_link(ACCESSIBILITY_HELP_LINK, Screen::Options)
                }
                Event::Narrator => self.narrator_status_changed(),
                Event::OpenStudioReplay(path) => {
                    let path = path.to_string_lossy().to_string();
                    if let Err(e) = self.open_studio_replay(&path) {
                        log::warn!("Horizon Studio: could not open {path}: {e}");
                    }
                }
                Event::OpenStudioFolder => {
                    let dir = std::path::PathBuf::from("recordings");
                    let _ = std::fs::create_dir_all(&dir);
                    super::packs::open_folder(&dir);
                }
            }
        }
        for action in self.ui.options.take_skin_actions() {
            match action {
                SkinAction::Name(name) => self.keep_player_name(&name),
                SkinAction::Choice(choice) => self.choose_own_skin(choice),
                SkinAction::OpenFolder => self.open_game_folder(&Self::skins_dir()),
                SkinAction::PickFile => self.pick_skin_file(),
                SkinAction::ElyBy(on) => self.keep_elyby(on),
                SkinAction::Upload(choice) => self.upload_own_skin(choice),
                SkinAction::ElySite => self.open_ely_skins(),
            }
        }
        Ok(())
    }
    /// LanguageManager.setSelected + reload: translations, then re-wrap chat.
    pub(super) fn load_language(&mut self, code: &str) {
        lang::set(lang::Language::load(&[&self.pack.source], code));
        self.refresh_remote_language();
        self.ui.chat.rescale(&self.gui.atlas);
        self.creative_screen.forget_items();
    }
    /// Window.updateFullscreenIfChanged: only a changed option asks the
    /// window to change, so applying settings never undoes a fullscreen
    /// the compositor set up.
    fn apply_fullscreen(&mut self) {
        // A splitscreen guest draws in a window it shares: its option never changes the window.
        if self.options.split_guest {
            return;
        }
        if let Some(w) = self.window.clone() {
            let monitor = w.current_monitor().or_else(|| w.primary_monitor());
            if let Some(modes) = self
                .video_modes
                .refresh(monitor, horizon_client::window::monitor_video_modes)
            {
                self.settings.video_modes = modes;
            }
            let in_video_screen = self.screen == Screen::Options && self.ui.options.video_open();
            let wanted = self.settings.fullscreen;
            let exclusive = self.settings.file.bool("exclusiveFullscreen");
            let preferred = self
                .settings
                .file
                .fullscreen_resolution
                .as_deref()
                .and_then(horizon_client::window::VideoMode::read);
            let leaving = !wanted && w.fullscreen().is_some();
            self.fullscreen
                .apply(&w, wanted, exclusive, preferred, in_video_screen);
            if leaving {
                windowed_again(&w);
            }
        }
    }
    /// Settings that Horizon applies beyond render distance, volume and GUI scale.
    pub(super) fn apply_ui_settings(&mut self) {
        let scale = self.world_scale();
        if horizon_client_render::mipmap::set_dither_cutouts(
            self.settings.horizon.dither_cutout_mips,
        ) {
            self.reload_packs();
        }
        self.apply_fullscreen();
        // A failed HDR start that named no driver becomes the window's driver's, and another
        // driver's is dropped, so HDR output is tried again.
        if let Some(driver) = self.renderer.as_ref().and_then(|r| r.hdr_driver())
            && self.settings.horizon.settle_failed_start(driver)
            && let Some(dir) = Self::options_path().parent()
        {
            self.settings.horizon.save(dir);
        }
        let s = &self.settings;
        if let Some(r) = self.renderer.as_mut() {
            r.gamma = s.gamma;
            r.fullbright = s.extras.fullbright;
            r.improved_transparency = s.improved_transparency;
            r.set_present_mode(s.vsync, s.horizon.present_mode);
            r.animated_textures = s.horizon.animated_textures;
            r.screenshot_quality = s.horizon.screenshot_quality;
            r.set_mipmap_levels(s.mipmap_levels.max(0) as u32);
            r.set_texture_filtering(
                s.file.int("textureFiltering"),
                s.file.int("maxAnisotropyBit"),
            );
            r.set_world_post(
                scale,
                s.horizon.fxaa,
                s.horizon.taa,
                s.horizon.upscaling.ratio(),
                s.horizon.upscaling_sharpness as f32 / 100.0,
            );
            r.set_frame_generation(
                s.horizon.frame_generation != horizon_client::graphics::FrameGeneration::Off,
            );
            r.set_hdr_lighting(s.horizon.hdr_lighting);
            // Where it is offered (`Renderer::gpu_culling_offer`); unchanged, it does nothing.
            // Auto has it on while its measurements say so (`GpuCullingAuto`), and starts over
            // when the choice is another one.
            let gpu_culling = match s.horizon.gpu_culling {
                horizon_client::graphics::GpuCullingMode::Off => false,
                horizon_client::graphics::GpuCullingMode::On => true,
                horizon_client::graphics::GpuCullingMode::Auto => self.gpu_culling_auto.on(),
            };
            if s.horizon.gpu_culling != horizon_client::graphics::GpuCullingMode::Auto {
                self.gpu_culling_auto.reset();
            }
            let _ = r.set_gpu_culling(gpu_culling);
            r.update_output(
                &s.horizon,
                &Self::options_path().with_file_name(horizon_client::graphics::HDR_MARKER),
            );
        }
        let mut volumes = s.volumes;
        volumes[0] = 1.0;
        // Splitscreen: the speakers are P1's, and so are their volumes.
        if !self.options.split_guest {
            horizon_client::settings::set_source_volumes(volumes);
        }
        super::narrator::sync(s);
        let chat = s.chat_options();
        let rescale = {
            let o = &self.ui.chat.options;
            o.width != chat.width || o.scale != chat.scale || o.line_spacing != chat.line_spacing
        };
        self.ui.chat.options = chat;
        if rescale {
            self.ui.chat.rescale(&self.gui.atlas);
        }
        let font = &mut self.gui.atlas.font;
        if font.uniform != s.force_unicode || font.japanese != s.japanese_glyphs {
            font.uniform = s.force_unicode;
            font.japanese = s.japanese_glyphs;
            font.reset_cache();
            self.ui.chat.rescale(&self.gui.atlas);
        }
        self.notify_window_resize();
        // The GUI scale is part of the screen's size (`Screen.resize`): a
        // change remakes its build before this frame draws it.
        self.build_screen();
        // 3D skin layers: a skin's slabs are built when it is resolved, so a
        // change here rebuilds the players already on screen (the Options
        // screen keeps resolving them every frame; this covers the console
        // and a setting restored from options.txt at start).
        if self.title.is_none() {
            self.update_remote_skins();
        }
    }
    pub(super) fn resize_state_of(&self, size: winit::dpi::PhysicalSize<u32>) -> ResizeState {
        let viewport = self
            .renderer
            .as_ref()
            .map_or([size.width, size.height], |r| {
                [r.config.width, r.config.height]
            });
        ResizeState {
            size,
            gui_size: horizon_client::window::GuiSize::new(
                viewport,
                self.settings.gui_scale,
                self.settings.force_unicode,
            )
            .size,
        }
    }
    /// Fires `window_resize` once when the physical or GUI-scaled dimensions change.
    pub(super) fn notify_window_resize(&mut self) {
        let Some(window) = &self.window else { return };
        let now = self.resize_state_of(window.inner_size());
        if now.differs_from(&mut self.resize_state) {
            self.native_window_resize(
                now.size.width,
                now.size.height,
                now.gui_size[0],
                now.gui_size[1],
            );
            self.build_screen();
        }
    }
    /// `Window.updateFullscreenState`: a fullscreen change made by the window
    /// system is adopted by the option (`Minecraft.fullscreenStateChanged`).
    pub(super) fn observe_fullscreen(&mut self) {
        // HDR calibration's own fullscreen is not the player's option: it
        // goes back to what it was when the calibration ends.
        if self.ui.options.calibration_window.is_some() {
            return;
        }
        let Some(w) = &self.window else { return };
        if self.options.split_guest {
            return;
        }
        if let Some(now) = self.fullscreen.observe(w.fullscreen().is_some())
            && self.settings.fullscreen != now
        {
            self.settings.fullscreen = now;
            self.settings.save(&Self::options_path());
            self.notify_window_resize();
        }
    }
    /// F11 (key.fullscreen): Window.toggleFullScreen, remembered in options.txt.
    pub(super) fn toggle_fullscreen(&mut self) {
        // Splitscreen: another player's F11 toggles the window it plays in, kept out of its
        // options (a profile that saved it would turn the next window fullscreen on joining).
        if self.options.split_guest {
            // Window 1 is P1's: its fullscreen follows P1's option, not a guest's key.
            if self.options.split_in_main_window {
                return;
            }
            if let Some(w) = &self.window {
                let on = w.fullscreen().is_none();
                if on {
                    let borderless = horizon_client::window::borderless_fullscreen(w);
                    horizon_client::window::enter_fullscreen(w, borderless);
                } else {
                    w.set_fullscreen(None);
                    windowed_again(w);
                }
            }
            return;
        }
        self.settings.fullscreen = !self.settings.fullscreen;
        self.settings.save(&Self::options_path());
        self.apply_ui_settings();
    }
    /// `FramerateLimitTracker.getFramerateLimit`: the Max Framerate option,
    /// throttled when minimised, idle, or in a menu without a world.
    pub(super) fn framerate_limit(&self) -> i32 {
        let context = FrameContext {
            inactivity: if self.settings.inactivity_fps_limit == "minimized" {
                InactivityFpsLimit::Minimized
            } else {
                InactivityFpsLimit::Afk
            },
            iconified: self
                .window
                .as_ref()
                .is_some_and(|w| w.is_minimized().unwrap_or(false)),
            focused: self.focused,
            // Window.isExclusiveFullscreen.
            exclusive_fullscreen: self
                .window
                .as_ref()
                .is_some_and(|w| matches!(w.fullscreen(), Some(Fullscreen::Exclusive(_)))),
            now_ms: self.started.elapsed().as_millis() as i64,
            latest_input_ms: self.last_input.duration_since(self.started).as_millis() as i64,
            has_level: self.title.is_none(),
            has_screen: self.title.is_some() || self.screen != super::Screen::Playing,
            has_overlay: false,
        };
        let limit = framerate_limit(self.settings.max_fps as i32, context);
        let limit = self
            .settings
            .horizon
            .battery_limit(limit, self.title.is_none(), self.focused);
        // A native mod may only lower it (`native_framerate_limit`).
        let mut hooked = limit;
        self.native_framerate_limit(
            self.focused,
            context.iconified,
            self.title.is_none(),
            &mut hooked,
        );
        if hooked >= 1 {
            hooked.min(limit)
        } else {
            limit
        }
    }
    /// `Minecraft.runTick`'s frame limiter: `FramerateLimiter.limitDisplayFPS`
    /// below 260 frames per second, sleeping then spin-waiting until the
    /// frame's slot ends (not in scripted frame-count runs).
    pub(super) fn limit_frame(&mut self) {
        if self.options.frames.is_some() || self.options.paced_by_split {
            return;
        }
        let limit = self.framerate_limit();
        match self.settings.horizon.pacing {
            horizon_client::graphics::Pacing::Precise => {
                horizon_client::window::end_frame(&mut self.limiter, limit, &mut self.frame_clock)
            }
            horizon_client::graphics::Pacing::Efficient => {
                let mut clock = horizon_client::window::SleepingClock(self.frame_clock);
                horizon_client::window::end_frame_on_grid(&mut self.limiter, limit, &mut clock);
            }
        }
    }
}

/// The named device can be a connected pad that has not driven the game yet.
fn detected_controller_style(
    device: Option<&horizon_client::controller_ui::Device>,
    fallback: horizon_client::gamepad::GlyphStyle,
) -> horizon_client::gamepad::GlyphStyle {
    device.map_or(fallback, |d| {
        horizon_client::gamepad::GlyphStyle::of_device(d.vendor, d.product)
    })
}

/// Out of fullscreen, a window that splitscreen opened to fill a monitor (no border, the
/// monitor's size) is a window again: its border back and, still covering the monitor, the game's
/// first size (854 x 480) in the middle of it, to be moved and sized.
fn windowed_again(w: &winit::window::Window) {
    // Only those: an ordinary window has its border, and its own size comes back by itself.
    if w.is_decorated() {
        return;
    }
    w.set_decorations(true);
    let Some(m) = w.current_monitor() else {
        return;
    };
    let (size, screen) = (w.inner_size(), m.size());
    if size.width >= screen.width && size.height >= screen.height {
        let scale = m.scale_factor();
        let small = winit::dpi::LogicalSize::new(854.0, 480.0).to_physical::<u32>(scale);
        let _ = w.request_inner_size(small);
        let at = m.position();
        w.set_outer_position(winit::dpi::PhysicalPosition::new(
            at.x + (screen.width.saturating_sub(small.width) / 2) as i32,
            at.y + (screen.height.saturating_sub(small.height) / 2) as i32,
        ));
    }
}

#[cfg(test)]
mod resize_state_tests {
    use super::ResizeState;
    use winit::dpi::PhysicalSize;

    fn state(width: u32, unicode: bool) -> ResizeState {
        ResizeState {
            size: PhysicalSize::new(width, 720),
            gui_size: horizon_client::window::GuiSize::new([width, 720], 3, unicode).size,
        }
    }

    #[test]
    #[ignore = "needs prepared resources and an X11 display"]
    fn viewport_resize_notifications_follow_each_player() {
        // Winit permits only one event loop per process, even after it is dropped.
        if crate::game::native_entity_refs::tests::run_fresh_cases(
            "game::options::resize_state_tests::viewport_resize_notifications_follow_each_player",
            "HORIZON_RESIZE_STATE_CHILD",
            &["window"],
        ) {
            return;
        }
        use mod_api::{ClientHost, Hooks, ModEntry, WindowResizeEvent, testing::with_mods};
        use std::sync::{Arc, Mutex};
        struct Listener(Arc<Mutex<Vec<(u32, u32, u32, u32)>>>);
        #[mod_api::__subscriptions]
        impl Hooks for Listener {
            fn window_resize(&self, _: &mut dyn ClientHost, event: &mut WindowResizeEvent) {
                self.0.lock().unwrap().push((
                    event.width,
                    event.height,
                    event.gui_width,
                    event.gui_height,
                ));
            }
        }
        let events = Arc::new(Mutex::new(Vec::new()));
        let mut builder = winit::event_loop::EventLoop::builder();
        #[cfg(target_os = "linux")]
        {
            use winit::platform::x11::EventLoopBuilderExtX11;
            builder.with_x11().with_any_thread(true);
        }
        let event_loop = builder.build().unwrap();
        #[allow(deprecated)]
        let window = Arc::new(
            event_loop
                .create_window(
                    winit::window::Window::default_attributes()
                        .with_visible(false)
                        .with_inner_size(PhysicalSize::new(1920, 1080)),
                )
                .unwrap(),
        );
        assert_eq!(window.inner_size(), PhysicalSize::new(1920, 1080));
        let mods = vec![ModEntry::new("resize", Box::new(Listener(events.clone())))].into();
        with_mods(mods, || {
            for (scale, expected) in [(0, (320, 360)), (2, (480, 540))] {
                super::super::native_entity_refs::tests::with_client_game(|game| {
                    game.options.offscreen = true;
                    game.window = Some(window.clone());
                    game.renderer = Some(game.new_renderer(window.clone()).unwrap());
                    game.renderer.as_mut().unwrap().resize(960, 1080);
                    game.settings.gui_scale = scale;
                    game.settings.force_unicode = false;
                    game.notify_window_resize();
                    game.notify_window_resize();
                    assert_eq!(
                        events.lock().unwrap().pop(),
                        Some((1920, 1080, expected.0, expected.1))
                    );
                    assert!(events.lock().unwrap().is_empty());
                    game.renderer.as_mut().unwrap().resize(1920, 1080);
                    game.notify_window_resize();
                    let gui = horizon_client::window::GuiSize::new([1920, 1080], scale, false).size;
                    assert_eq!(
                        events.lock().unwrap().pop(),
                        Some((1920, 1080, gui[0], gui[1]))
                    );
                    game.notify_window_resize();
                    assert!(events.lock().unwrap().is_empty());
                });
            }
        });
    }

    /// One resize event that also flips fullscreen is observed twice (by the fullscreen
    /// observer and by the resize handler) but reported once.
    #[test]
    fn overlapping_observers_report_a_change_once() {
        let mut last = Some(state(640, false));
        let now = state(800, true);
        assert!(now.differs_from(&mut last));
        assert!(!now.differs_from(&mut last));
    }

    /// A settings-only change at an unchanged physical size still reports.
    #[test]
    fn a_settings_only_change_reports() {
        let mut last = Some(state(960, false));
        assert!(!state(960, false).differs_from(&mut last));
        assert!(state(960, true).differs_from(&mut last));
    }
    #[test]
    fn settings_that_leave_dimensions_unchanged_do_not_report() {
        let size = PhysicalSize::new(1280, 960);
        let before = ResizeState {
            size,
            gui_size: horizon_client::window::GuiSize::new([1280, 960], 2, false).size,
        };
        let mut last = Some(before);
        let unicode = ResizeState {
            size,
            gui_size: horizon_client::window::GuiSize::new([1280, 960], 2, true).size,
        };
        assert!(!unicode.differs_from(&mut last));
        let automatic = ResizeState {
            size,
            gui_size: horizon_client::window::GuiSize::new([1280, 960], 0, false).size,
        };
        assert!(automatic.differs_from(&mut last));
        let larger_limit = ResizeState {
            size,
            gui_size: horizon_client::window::GuiSize::new([1280, 960], 100, false).size,
        };
        assert!(!larger_limit.differs_from(&mut last));
    }
}

#[cfg(test)]
mod controller_context_tests {
    use super::detected_controller_style;
    use horizon_client::{controller_ui::Device, gamepad::GlyphStyle};

    #[test]
    fn detected_style_follows_the_named_device_even_before_it_is_used() {
        let mut device = Device {
            name: "pad".into(),
            vendor: Some(0x054c),
            product: None,
        };
        assert_eq!(
            detected_controller_style(Some(&device), GlyphStyle::Xbox),
            GlyphStyle::PlayStation
        );
        device.vendor = Some(0x057e);
        assert_eq!(
            detected_controller_style(Some(&device), GlyphStyle::PlayStation),
            GlyphStyle::Nintendo
        );
        assert_eq!(
            detected_controller_style(None, GlyphStyle::PlayStation),
            GlyphStyle::PlayStation
        );
    }
}
